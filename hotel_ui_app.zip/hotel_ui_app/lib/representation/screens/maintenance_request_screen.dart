import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hotel_ui_app/representation/screens/add_maintainance_screen.dart';
import 'package:hotel_ui_app/representation/widgets/app_bar_container.dart';
import '../../core/constant/color_constant.dart';
import '../../core/constant/dismension_constant.dart';
import '../../core/service/api_service.dart';
import '../widgets/item_services_widget.dart';  // Import widget mới

class MaintenanceRequestScreen extends StatefulWidget {
  const MaintenanceRequestScreen({Key? key}) : super(key: key);

  static const routeName = '/maintenance_request_screen';

  @override
  State<MaintenanceRequestScreen> createState() => _MaintenanceRequestScreen();
}

class _MaintenanceRequestScreen extends State<MaintenanceRequestScreen> {
  final ApiService apiService = ApiService();
  List<dynamic> request = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchMaintainance();
  }

  Future<void> fetchMaintainance() async {
    try {
      final data = await apiService.fetchAllMaintenanceRequest();
      setState(() {
        request = data;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  Future<void> deleteRequest(int requestId) async {
    try {
      final success = await apiService.deleteMaintainance(requestId);
      if (success) {
        fetchMaintainance();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Bảo trì đã được xóa')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Không thể xóa bảo trì')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi khi xóa bảo trì: $e')),
      );
    }
  }
  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: Column(
        children: [
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : request.isEmpty
                ? const Center(child: Text('Không có yêu cầu bảo trì nào để hiển thị'))
                : ListView.builder(
              itemCount: request.length,
              itemBuilder: (context, index) {
                final requests = request[index];
                final requestId = requests['MaYC'];
                final roomNumber = requests['Phong']['SoPhong']?.toString() ?? 'Không rõ';
                final roomType = requests['Phong']['LoaiPhong'] ?? 'Không rõ loại phòng';
                final requestDate = requests['NgayYC'] ?? 'Không rõ';
                final completionDate = requests['NgayHoanThanh'] ?? 'Không rõ';
                return GestureDetector(
                  onLongPress: () {
                    // Hiển thị dialog xác nhận xóa
                    showDialog(
                      context: context,
                      builder: (context) {
                        return AlertDialog(
                          title: const Text('Xác nhận xóa'),
                          content: const Text(
                              'Bạn có chắc chắn muốn xóa lượt bảo trì này không?'),
                          actions: [
                            TextButton(
                              onPressed: () {
                                Navigator.of(context)
                                    .pop(); // Đóng dialog nếu hủy
                              },
                              child: const Text('Hủy'),
                            ),
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop(); // Đóng dialog
                                deleteRequest(requestId); // Gọi API xóa
                              },
                              child: const Text('Xóa'),
                            ),
                          ],
                        );
                      },
                    );
                  },
                  child: ItemServicesWidget(
                    icon: FontAwesomeIcons.hammer,  // Biểu tượng có thể thay đổi
                    label: 'Phòng: $roomNumber',
                    value: 'Loại Phòng: $roomType',
                    detail: {
                      'Ngày Hoàn Thành': completionDate,
                      'Ngày Gửi Yêu Cầu': requestDate,
                    },
                  ),
                );
              },
            ),
          ),
          SizedBox(
            height: kMediumPadding,
          ),
          SizedBox(
            width: double.infinity, // Đặt chiều rộng nút chiếm toàn bộ chiều ngang
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(context).pushNamed(AddMaintainanceScreen.routeName);
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor: ColorPalette.buttonColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                shadowColor: Colors.black.withOpacity(0.25),
                elevation: 8,
              ),
              child: const Text(
                "Thêm Bảo Trì Mới",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
