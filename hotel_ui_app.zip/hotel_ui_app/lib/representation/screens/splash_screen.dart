import 'package:flutter/material.dart';
import 'package:hotel_ui_app/core/helper/asset_helper.dart';
import 'package:hotel_ui_app/core/helper/image_helper.dart';
import 'package:hotel_ui_app/representation/screens/intro_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  static const routeName = '/splash_screen';

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  @override
  void initState() {
    super.initState();
    redirectIntroScreen(); //delay ở Splash Screen 3 giây để load API sau đó chuyển hướng vào Intro Screen
  }

  void redirectIntroScreen() async
  {
    await Future.delayed(const Duration(seconds: 3)); //delay 3s
    Navigator.of(context).pushNamed(IntroScreen.routeName); //chuyen huong den man hinh Intro
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill
          (child: ImageHelper.loadFromAsset
          (AssetHelper.imageBackgroundintro,
            fit: BoxFit.fitWidth,
        ),
        ),
        Positioned.fill(
            child: ImageHelper.loadFromAsset(AssetHelper.imageNameintro)),
      ],
    );
  }
}
