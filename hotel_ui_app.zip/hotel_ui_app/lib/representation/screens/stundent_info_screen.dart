import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hotel_ui_app/representation/widgets/app_bar_container.dart';
import 'package:hotel_ui_app/representation/widgets/item_customers_widget.dart';
import 'package:hotel_ui_app/core/helper/asset_helper.dart';
import '../../core/helper/shared_preferences_helper.dart';
import '../../core/service/api_service.dart';

class StundentInfoScreen extends StatefulWidget {
  const StundentInfoScreen({Key? key}) : super(key: key);

  static const routeName = '/profile_screen_user';

  @override
  State<StundentInfoScreen> createState() => _ProfileScreenUserState();
}

class _ProfileScreenUserState extends State<StundentInfoScreen> {
  String _customerId = "";
  String _userRole = "";
  Future<Map<String, dynamic>>? _customerInfo; // Chuyển sang nullable

  // Hàm tải thông tin khách hàng
  _loadCustomerInfo() async {
    final customerId = await SharedPreferencesHelper.getCustomerId();
    setState(() {
      _customerId = customerId!;
      _customerInfo = ApiService().fetchCustomerById(_customerId); // Gọi API với customerId
    });
  }
  Future<void> _loadUserRole() async {
    final role = await SharedPreferencesHelper.getUserRole();  // Giả sử bạn có hàm này để lấy role
    setState(() {
      _userRole = role ?? '';
    });
  }

  @override
  void initState() {
    super.initState();
    _loadCustomerInfo();
    _loadUserRole();
  }

  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: Column(
        children: [
          Image.asset(
            AssetHelper.imageProfile,
            width: 200,
            height: 200,
          ),
          const SizedBox(height: 8),
          Text(
            _userRole == 'admin' ? "Admin" : "User",
            style: const TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          Expanded(
            child: FutureBuilder<Map<String, dynamic>>(
              future: _customerInfo,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Center(
                    child: Text(
                      'Error: ${snapshot.error}',
                      style: const TextStyle(color: Colors.red),
                    ),
                  );
                } else if (snapshot.hasData) {
                  final customerData = snapshot.data!;
                  return ListView(
                    children: [
                      Card(
                        margin: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ItemProfileWidget(
                                label: 'Tên:',
                                value: customerData['Ten'] ?? 'N/A',
                                icon: Icons.person,
                              ),
                              const SizedBox(height: 8),
                              ItemProfileWidget(
                                label: 'SĐT:',
                                value: customerData['SDT'] ?? 'N/A',
                                icon: Icons.phone,
                              ),
                              const SizedBox(height: 8),
                              ItemProfileWidget(
                                label: 'Email:',
                                value: customerData['Email'] ?? 'N/A',
                                icon: Icons.email,
                              ),
                              const SizedBox(height: 8),
                              ItemProfileWidget(
                                label: 'Địa chỉ:',
                                value: customerData['DiaChi'] ?? 'N/A',
                                icon: FontAwesomeIcons.house,
                              ),
                              const SizedBox(height: 8),
                              ItemProfileWidget(
                                label: 'Thành viên:',
                                value: customerData['Loai'] ?? 'N/A',
                                icon: FontAwesomeIcons.star,
                              ),
                              const SizedBox(height: 8),
                            ],
                          ),
                        ),
                      ),
                    ],
                  );
                } else {
                  return const Center(child: Text('No data available.'));
                }
              },
            ),
          ),
        ],
      ),
    );
  }
}
