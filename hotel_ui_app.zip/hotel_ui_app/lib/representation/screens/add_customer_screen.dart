import 'package:flutter/material.dart';
import '../../core/service/api_service.dart';
import '../widgets/app_bar_container.dart';

class AddCustomerScreen extends StatefulWidget {
  const AddCustomerScreen({super.key});

  static const routeName = '/add_customer_screen';

  @override
  State<AddCustomerScreen> createState() => _AddCustomerScreenState();
}

class _AddCustomerScreenState extends State<AddCustomerScreen> {
  final ApiService apiService = ApiService();
  final _formKey = GlobalKey<FormState>();

  String _customerId = '';
  String _customerName = ''; // Tên khách hàng
  String _phoneNumber = '';  // Số điện thoại
  String _email = '';        // Email
  String _address = '';      // Địa chỉ
  String _dob = '';          // Ngày sinh
  String _customerType = '';
  String _customerImg= '';// Loại khách hàng

  // Hàm gọi API để thêm khách hàng
  Future<void> _createCustomer() async {
    if (_formKey.currentState?.validate() ?? false) {
      try {
        final success = await apiService.createCustomer(
          _customerId,
          _customerName,
          _phoneNumber,
          _email,
          _address,
          _dob,
          _customerType,
          _customerImg,
        );
        if (success) {
          Navigator.of(context).pop(true); // Trả về 'true' khi thêm thành công
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Thêm khách hàng thành công')),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Không thể thêm khách hàng')),
          );
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Lỗi khi thêm khách hàng: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Thêm khách hàng mới',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 16.0),
            Form(
              key: _formKey,
              child: Column(
                children: [
                  // MaKhachHang (ID khách hàng)
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Mã khách hàng'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Vui lòng nhập mã khách hàng';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      _customerId = value;
                    },
                  ),
                  const SizedBox(height: 16.0),
                  // Tên khách hàng
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Tên khách hàng'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Vui lòng nhập tên khách hàng';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      _customerName = value;
                    },
                  ),
                  const SizedBox(height: 16.0),
                  // Số điện thoại
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Số điện thoại'),
                    keyboardType: TextInputType.phone,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Vui lòng nhập số điện thoại';
                      }
                      if (!RegExp(r'^\d{10,11}$').hasMatch(value)) {
                        return 'Số điện thoại không hợp lệ';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      _phoneNumber = value;
                    },
                  ),
                  const SizedBox(height: 16.0),
                  // Email
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Email'),
                    keyboardType: TextInputType.emailAddress,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Vui lòng nhập email';
                      }
                      if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(value)) {
                        return 'Email không hợp lệ';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      _email = value;
                    },
                  ),
                  const SizedBox(height: 16.0),
                  // Địa chỉ
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Địa chỉ'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Vui lòng nhập địa chỉ';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      _address = value;
                    },
                  ),
                  const SizedBox(height: 16.0),
                  // Ngày sinh
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Ngày sinh (YYYY-MM-DD)'),
                    keyboardType: TextInputType.datetime,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Vui lòng nhập ngày sinh';
                      }
                      if (!RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(value)) {
                        return 'Ngày sinh không hợp lệ (định dạng: YYYY-MM-DD)';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      _dob = value;
                    },
                  ),
                  const SizedBox(height: 16.0),
                  // Loại khách hàng
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Loại khách hàng'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Vui lòng nhập loại khách hàng';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      _customerType = value;
                    },
                  ),
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Img khách hàng'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Vui lòng nhập link image khách hàng';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      _customerImg = value;
                    },
                  ),
                  const SizedBox(height: 32.0),
                  ElevatedButton(
                    onPressed: _createCustomer,
                    child: const Text('Thêm khách hàng'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
