import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:hotel_ui_app/representation/screen_for_user/home_screen_user.dart';
import 'package:hotel_ui_app/representation/screen_for_user/main_screen_user.dart';
import 'package:hotel_ui_app/core/service/api_service.dart';
import 'package:hotel_ui_app/core/helper/shared_preferences_helper.dart';
import 'package:hotel_ui_app/core/constant/color_constant.dart';
import 'package:hotel_ui_app/core/helper/asset_helper.dart';
import 'package:hotel_ui_app/representation/screens/login_screen.dart';

import 'main_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  static const routeName = '/register_screen';

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  // Hàm gọi API đăng nhập
  Future<void> _onLogin() async {
    final email = _usernameController.text;
    final password = _passwordController.text;

    if (email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Vui lòng nhập đầy đủ email và mật khẩu")),
      );
      return;
    }

    try {
      final data = await ApiService().login(email, password);
      print("Dữ liệu trả về: $data");
      if (data.containsKey('data') && data['data'].containsKey('customerId')) {
        final customerId = (data['data']['customerId'] is int)
            ? data['data']['customerId']
            : int.parse(data['data']['customerId'].toString());
        await SharedPreferencesHelper.saveCustomerId(customerId.toString());

        final userRole = (data['data']['role']);
        await SharedPreferencesHelper.saveUserRole(userRole);

        // Điều hướng dựa trên role
        if (data['data']['role'] == 'admin') {
          Navigator.of(context).pushReplacementNamed(MainScreen.routeName);
        } else {
          Navigator.of(context).pushReplacementNamed(MainScreenUser.routeName);
        }
      } else {
        throw Exception('Dữ liệu đăng nhập không hợp lệ.Dữ liệu trả về: $data');
      }
    } catch (error) {
      print("Error: $error");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi: $error')),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Column(
                children: [
                  Image.asset(
                    AssetHelper.imageLogo,
                    width: 100,
                    height: 100,
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    "Đăng Nhập ",
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 32),
              Column(
                children: [
                  TextFormField(
                    controller: _usernameController,
                    decoration: InputDecoration(
                      hintText: "Nhập tên tài khoản",
                      prefixIcon: const Icon(Icons.person),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _passwordController,
                    obscureText: true,
                    decoration: InputDecoration(
                      hintText: "Nhập mật khẩu",
                      prefixIcon: const Icon(Icons.lock),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _onLogin,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: ColorPalette.buttonColor,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      minimumSize: const Size(double.infinity, 48),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: const Text(
                      "Đăng nhập",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          "Chưa có tài khoản?",
                          style: TextStyle(fontSize: 18),
                        ),
                        TextButton(
                          onPressed: () {
                            Navigator.of(context).pushNamed(LoginScreen.routeName);
                          },
                          child: const Text(
                            "Đăng ký",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: ColorPalette.buttonColor,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
