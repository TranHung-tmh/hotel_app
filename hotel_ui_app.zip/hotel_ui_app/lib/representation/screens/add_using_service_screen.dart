import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hotel_ui_app/representation/screens/profile_screen.dart';
import 'package:hotel_ui_app/representation/screens/services_screen.dart';
import '../../core/constant/color_constant.dart';
import '../../core/constant/dismension_constant.dart';
import '../../core/service/api_service.dart';
import '../widgets/app_bar_container.dart';
import '../widgets/item_booking_widget.dart';

class AddUsingServiceScreen extends StatefulWidget {
  const AddUsingServiceScreen({Key? key}) : super(key: key);

  static const routeName = '/add_using_service_screen';

  @override
  State<AddUsingServiceScreen> createState() => _AddUsingServiceScreenState();
}

class _AddUsingServiceScreenState extends State<AddUsingServiceScreen> {
  final ApiService apiService = ApiService();

  String? selectedCustomerId;
  String? selectedCustomerName;
  String? selectedServiceId;
  String? selectedServiceName;
  DateTime? usingDate;
  int? quantity;
  double? totalAmount;

  Future<void> _createUsingService() async {
    if (selectedCustomerId == null ||
        selectedServiceId == null ||
        usingDate == null ||
        quantity == null ||
        totalAmount == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Vui lòng nhập đầy đủ thông tin!")),
      );
      return;
    }

    final formData = {
      "MaKhachHang": int.tryParse(selectedCustomerId!),
      "MaDichVu": int.tryParse(selectedServiceId!),
      "NgaySuDung": usingDate!.toIso8601String().split("T").first,
      "SoLuong": quantity,
      "TongTien": totalAmount
    };

    try {
      bool success = await apiService.createServiceUsage(formData);
      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Thêm lượt sử dụng dịch vụ thành công!")),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Thêm lượt sử dụng dịch vụ thất bại!")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Lỗi: $e")),
      );
    }
  }

  Future<void> _selectUsingDate() async {
    final DateTime? selected = await showDatePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
      initialDate: DateTime.now(),
    );

    if (selected != null) {
      setState(() {
        usingDate = selected;
      });
    }
  }


  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ItemBookingWidget(
              icon: FontAwesomeIcons.solidUser,
              label: "Thông tin khách hàng: ",
              value: selectedCustomerName != null
                  ? '[$selectedCustomerId] $selectedCustomerName'
                  : 'Chọn khách hàng',
              onTap: () async {
                final result = await Navigator.of(context).pushNamed(ProfileScreen.routeName);
                if (result != null && result is Map) {
                  setState(() {
                    selectedCustomerId = result['id'] ?? '';
                    selectedCustomerName = result['name'] ?? '';
                  });
                }
              },
            ),
            ItemBookingWidget(
              icon: Icons.room_service,
              label: "Dịch vụ:",
              value: selectedServiceName != null
                  ? '[$selectedServiceId] $selectedServiceName'
                  : 'Chọn dịch vụ',
              onTap: () async {
                final result = await Navigator.of(context).pushNamed(ServicesScreen.routeName);
                if (result != null && result is Map) {
                  setState(() {
                    selectedServiceId = result['id'] ?? '';
                    selectedServiceName = result['name'] ?? '';
                  });
                }
              },
            ),
            ItemBookingWidget(
              icon: Icons.calendar_today,
              label: "Ngày sử dụng:",
              value: usingDate == null
                  ? "Chưa chọn"
                  : "${usingDate!.day}/${usingDate!.month}/${usingDate!.year}",
              onTap: _selectUsingDate,
            ),
            ItemBookingWidget(
              icon: Icons.format_list_numbered,
              label: "Số lượng:",
              value: quantity == null ? "Nhập số lượng" : quantity.toString(),
              onTap: () async {
                final input = await _showInputDialog("Nhập số lượng");
                if (input != null) {
                  setState(() {
                    quantity = int.tryParse(input);
                  });
                }
              },
            ),
            ItemBookingWidget(
              icon: Icons.attach_money,
              label: "Tổng tiền:",
              value: totalAmount == null
                  ? "Nhập tổng tiền"
                  : "${totalAmount?.toStringAsFixed(2)}",
              onTap: () async {
                final input = await _showInputDialog("Nhập tổng tiền");
                if (input != null) {
                  setState(() {
                    totalAmount = double.tryParse(input);
                  });
                }
              },
            ),
            const SizedBox(height: kDefaultPadding),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _createUsingService,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: ColorPalette.buttonColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  shadowColor: Colors.black.withOpacity(0.25),
                  elevation: 8,
                ),
                child: const Text(
                  "Thêm Lượt Sử Dụng Dịch Vụ",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<String?> _showInputDialog(String title) async {
    String? value;
    await showDialog<String>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(title),
          content: TextField(
            keyboardType: TextInputType.number,
            onChanged: (text) {
              value = text;
            },
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text("Hủy"),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(value),
              child: const Text("Xác nhận"),
            ),
          ],
        );
      },
    );
    return value;
  }
}
