import 'package:flutter/material.dart';
import 'package:hotel_ui_app/representation/screens/login_screen.dart';
import 'package:hotel_ui_app/representation/screens/register_screen.dart';
import 'package:hotel_ui_app/representation/screens/splash_screen.dart';
import '../../core/helper/asset_helper.dart';

class IntroScreen extends StatefulWidget {
  const IntroScreen({Key? key}) : super(key: key);

  static const routeName = '/intro_screen';

  @override
  State<IntroScreen> createState() => _IntroScreenState();
}

class _IntroScreenState extends State<IntroScreen> {
  int _selectedIndex = 0; // Tab hiện tại
  final PageController _pageController = PageController();

  final List<Map<String, String>> _tabData = [
    {
      'image': AssetHelper.imageIntro1,
      'title': 'Hotels',
      'description': 'Khám phá danh mục các phòng nghỉ phong phú và đa dạng từ các phòng tiêu chuẩn tiện nghi cho đến các phòng cao cấp.',
    },
    {
      'image': AssetHelper.imageIntro2,
      'title': 'Foods',
      'description': 'Thưởng thức các món ăn đặc sản đa dạng, được chế biến bởi các đầu bếp chuyên nghiệp hàng đầu.',
    },
    {
      'image': AssetHelper.imageIntro3,
      'title': 'Activities',
      'description': 'Trải nghiệm các hoạt động thú vị, từ khám phá thiên nhiên đến các buổi biểu diễn đặc sắc.',
    },
  ];

  void _onTabSelected(int index) {
    setState(() {
      _selectedIndex = index;
      _pageController.animateToPage(
        index,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    });
  }

  void _onNextPressed() {
    if (_selectedIndex < _tabData.length - 1) {
      _pageController.animateToPage(
        _selectedIndex + 1,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    } else {
      Navigator.of(context).pushNamed(RegisterScreen.routeName);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // PageView
          Container(
            height: MediaQuery.of(context).size.height,
            child: PageView.builder(
              controller: _pageController,
              onPageChanged: (index) {
                setState(() {
                  _selectedIndex = index;
                });
              },
              itemCount: _tabData.length,
              itemBuilder: (context, index) {
                return ClipRRect(
                  borderRadius: const BorderRadius.vertical(bottom: Radius.circular(30)),
                  child: Image.asset(
                    _tabData[index]['image']!,
                    width: double.infinity,
                    height: MediaQuery.of(context).size.height,
                    fit: BoxFit.cover,
                  ),
                );
              },
            ),
          ),

          // Content
          Align(
            alignment: Alignment.bottomCenter,
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
              child: Container(
                height: MediaQuery.of(context).size.height * 0.35,
                color: Colors.white,
                child: Column(
                  children: [
                    // Tabs
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(
                          _tabData.length,
                              (index) => Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8.0),
                            child: GestureDetector(
                              onTap: () => _onTabSelected(index),
                              child: Container(
                                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                                decoration: BoxDecoration(
                                  color: _selectedIndex == index ? const Color(0xFFC9D4E4) : Colors.white,
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                    color: _selectedIndex == index ? Colors.white : Colors.grey.shade300,
                                  ),
                                ),
                                child: Text(
                                  _tabData[index]['title']!,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: _selectedIndex == index ? Colors.black : Colors.black,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),

                    // Description
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Text(
                              "THÔNG TIN",
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24, color: Colors.black),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              _tabData[_selectedIndex]['description']!,
                              style: const TextStyle(fontSize: 16, height: 1.5),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Indicator & Button
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          // Indicator
                          Row(
                            children: List.generate(
                              _tabData.length,
                                  (index) => Container(
                                margin: const EdgeInsets.symmetric(horizontal: 4),
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: _selectedIndex == index ? Colors.blue : Colors.grey.shade300,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ),
                          ),

                          // Button
                          ElevatedButton(
                            onPressed: _onNextPressed,
                            style: ElevatedButton.styleFrom(
                              foregroundColor: Colors.white,
                              backgroundColor: const Color(0xFF598BD5),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                              ),
                              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
                            ),
                            child: Text(
                              _selectedIndex == _tabData.length - 1 ? "Get Started !" : "Next",
                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
