import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hotel_ui_app/core/constant/color_constant.dart';
import 'package:hotel_ui_app/core/helper/asset_helper.dart';
import 'package:hotel_ui_app/representation/screens/register_screen.dart';

import '../../core/constant/textstyle_constants.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  static const routeName = '/login_screen';

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _isAcceptedTerms = false; // Trạng thái checkbox
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();

  void _onRegister() {
    if (!_isAcceptedTerms) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Vui lòng chấp nhận điều khoản trước khi đăng ký")),
      );
      return;
    }

    if (_passwordController.text != _confirmPasswordController.text) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Mật khẩu không khớp")),
      );
      return;
    }

    // Logic đăng ký
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Đăng ký thành công! Chào mừng, ${_usernameController.text}")),
    );
  }

  void _onLogin() {
    Navigator.of(context).pushNamed(RegisterScreen.routeName);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Icon và tiêu đề
              Column(
                children: [
                  Image.asset(
                    AssetHelper.imageLogo, // Thay bằng đường dẫn hình ảnh của bạn
                    width: 100,
                    height: 100,
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    "Đăng Ký",
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 32),

              // Form các trường nhập liệu
              Column(
                children: [
                  // Tên tài khoản
                  TextFormField(
                    controller: _usernameController,
                    decoration: InputDecoration(
                      hintText: "Nhập tên tài khoản",
                      prefixIcon: const Icon(Icons.person),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Địa chỉ Email
                  TextFormField(
                    controller: _emailController,
                    decoration: InputDecoration(
                      hintText: "Nhập email",
                      prefixIcon: const Icon(Icons.email),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Mật khẩu
                  TextFormField(
                    controller: _passwordController,
                    obscureText: true,
                    decoration: InputDecoration(
                      hintText: "Nhập mật khẩu",
                      prefixIcon: const Icon(Icons.lock),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Nhập lại mật khẩu
                  TextFormField(
                    controller: _confirmPasswordController,
                    obscureText: true,
                    decoration: InputDecoration(
                      hintText: "Xác nhận lại mật khẩu",
                      prefixIcon: const Icon(Icons.lock),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // Checkbox
              Row(
                children: [
                  Checkbox(
                    value: _isAcceptedTerms,
                    onChanged: (value) {
                      setState(() {
                        _isAcceptedTerms = value ?? false;
                      });
                    },
                    activeColor: ColorPalette.buttonColor,
                  ),
                  const Expanded(
                    child: Text(
                      "Chấp nhận điều khoản của chúng tôi",
                      style: TextStyle(fontSize: 18)
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // Nút Đăng ký
              ElevatedButton(
                onPressed: _onRegister,
                style: ElevatedButton.styleFrom(
                  backgroundColor: ColorPalette.buttonColor,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text(
                  "Đăng Ký",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Đã có tài khoản? Đăng nhập
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      "Đã có tài khoản?",
                      style: TextStyle(fontSize: 18),
                    ),
                    TextButton(
                      onPressed: _onLogin,
                      child: const Text(
                        "Đăng nhập",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: ColorPalette.buttonColor,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Social Media Login
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    onPressed: () {
                      // Thêm logic xử lý đăng nhập Facebook
                    },
                    icon: const Icon(FontAwesomeIcons.facebook),
                    iconSize: 32,
                    color: const Color(0xFF808080),
                  ),
                  const SizedBox(width: 16),
                  IconButton(
                    onPressed: () {
                      // Thêm logic xử lý đăng nhập Google
                    },
                    icon: const Icon(FontAwesomeIcons.squareXTwitter),
                    iconSize: 32,
                    color: const Color(0xFF808080),
                  ),
                  const SizedBox(width: 16),
                  IconButton(
                    onPressed: () {
                      // Thêm logic xử lý đăng nhập Call
                    },
                    icon: const Icon(FontAwesomeIcons.instagram),
                    iconSize: 32,
                    color: const Color(0xFF808080),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
