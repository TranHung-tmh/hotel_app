import 'package:flutter/material.dart';
import '../../core/service/api_service.dart';
import '../widgets/app_bar_container.dart';

class AddRoomScreen extends StatefulWidget {
  const AddRoomScreen({super.key});

  static const routeName = '/add_room_screen';

  @override
  State<AddRoomScreen> createState() => _AddRoomScreenState();
}

class _AddRoomScreenState extends State<AddRoomScreen> {
  final ApiService apiService = ApiService();
  final _formKey = GlobalKey<FormState>();
  String _roomNumber = '';  // Số phòng
  String _roomType = '';    // Loại phòng
  String _roomPrice = '';   // Giá phòng
  String _roomStatus = '';  // Tình trạng phòng

  // Hàm gọi API để tạo phòng mới
  Future<void> _createRoom() async {
    if (_formKey.currentState?.validate() ?? false) {
      try {
        final success = await apiService.createRoom(
          _roomNumber,
          _roomType,
          _roomPrice,
          _roomStatus,
        );
        if (success) {
          Navigator.of(context).pop();
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Thêm phòng thành công')),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Không thể thêm phòng')),
          );
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Lỗi khi thêm phòng: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Thêm phòng mới',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 16.0),
            Form(
              key: _formKey,
              child: Column(
                children: [
                  // Số phòng
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Số phòng'),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Vui lòng nhập số phòng';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      _roomNumber = value;
                    },
                  ),
                  const SizedBox(height: 16.0),
                  // Loại phòng
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Loại phòng'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Vui lòng nhập loại phòng';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      _roomType = value;
                    },
                  ),
                  const SizedBox(height: 16.0),
                  // Giá phòng
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Giá phòng'),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Vui lòng nhập giá phòng';
                      }
                      if (double.tryParse(value) == null) {
                        return 'Giá phòng không hợp lệ';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      _roomPrice = value;
                    },
                  ),
                  const SizedBox(height: 16.0),
                  // Tình trạng phòng
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Tình trạng phòng'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Vui lòng nhập tình trạng phòng';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      _roomStatus = value;
                    },
                  ),
                  const SizedBox(height: 32.0),
                  ElevatedButton(
                    onPressed: _createRoom,
                    child: const Text('Thêm phòng'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
