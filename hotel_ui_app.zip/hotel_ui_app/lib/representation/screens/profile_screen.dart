import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:cached_network_image/cached_network_image.dart'; // Import thư viện hiển thị ảnh từ URL
import 'package:hotel_ui_app/core/constant/color_constant.dart';
import '../../core/service/api_service.dart';
import '../widgets/app_bar_container.dart';
import '../widgets/item_customers_widget.dart';
import 'add_customer_screen.dart'; // Import màn hình thêm khách hàng

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  static const routeName = '/profile_screen';

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final ApiService apiService = ApiService();
  List<dynamic> customers = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchCustomers();
  }

  Future<void> fetchCustomers() async {
    try {
      final data = await apiService.fetchAllCustomers();
      setState(() {
        customers = data;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: Column(
        children: [
          if (isLoading)
            const Center(child: CircularProgressIndicator())
          else if (customers.isEmpty)
            const Center(child: Text('Không có thông tin khách hàng để hiển thị'))
          else
            Expanded(
              child: ListView.builder(
                itemCount: customers.length,
                itemBuilder: (context, index) {
                  final customer = customers[index];
                  return GestureDetector(  // Wrap the Card with GestureDetector to detect clicks
                    onTap: () {
                      Navigator.of(context).pop({
                        'id': customer['MaKhachHang'].toString(),
                        'name': customer['Ten']
                      });
                    },
                    child: Card(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CachedNetworkImage(
                              imageUrl: customer['HinhAnh'] ?? '',
                              placeholder: (context, url) => const CircularProgressIndicator(),
                              errorWidget: (context, url, error) => const Icon(Icons.error),
                              width: 80,
                              height: 80,
                              fit: BoxFit.cover,
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    customer['Ten'] ?? 'Không có tên',
                                    style: const TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(height: 12),
                                  ItemProfileWidget(
                                    label: 'Địa chỉ:',
                                    value: customer['DiaChi'] ?? 'Không rõ',
                                    icon: Icons.location_on,
                                  ),
                                  const SizedBox(height: 8),
                                  ItemProfileWidget(
                                    label: 'Số điện thoại:',
                                    value: customer['SDT'] ?? 'Không rõ',
                                    icon: Icons.phone,
                                  ),
                                  const SizedBox(height: 8),
                                  ItemProfileWidget(
                                    label: 'Ngày sinh:',
                                    value: customer['NgaySinh'] ?? 'Không rõ',
                                    icon: FontAwesomeIcons.cakeCandles,
                                  ),
                                  const SizedBox(height: 8),
                                  ItemProfileWidget(
                                    label: 'Loại khách hàng:',
                                    value: customer['Loai'] ?? 'Không rõ',
                                    icon: Icons.card_membership,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(context).pushNamed(AddCustomerScreen.routeName);
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor: ColorPalette.buttonColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                shadowColor: Colors.black.withOpacity(0.25),
                elevation: 8,
              ),
              child: const Text(
                "Thêm Khách Hàng Mới",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}
