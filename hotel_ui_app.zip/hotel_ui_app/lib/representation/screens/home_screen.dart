import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:hotel_ui_app/core/helper/asset_helper.dart';
import 'package:hotel_ui_app/core/helper/image_helper.dart';
import 'package:hotel_ui_app/representation/screens/maintenance_request_screen.dart';
import 'package:hotel_ui_app/representation/screens/rooms_screen.dart';
import 'package:hotel_ui_app/representation/screens/add_room_screen.dart';
import 'package:hotel_ui_app/representation/screens/services_screen.dart';
import 'package:hotel_ui_app/representation/widgets/app_bar_container.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  static const routeName = '/home_screen';

  Widget _buildItemCategory(Widget img, Function() onTap, String title) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            height: 120,
            width: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: img,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            title,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }



  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Text(
                "Categories",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround, // Căn đều các mục
              children: [
                _buildItemCategory(
                  ImageHelper.loadFromAsset(AssetHelper.imageRoomsButton),
                      () {
                    Navigator.of(context).pushNamed(RoomsScreen.routeName);
                  },
                  'Rooms',
                ),
                _buildItemCategory(
                  ImageHelper.loadFromAsset(AssetHelper.imageMaintenanceButton),
                      () {
                    Navigator.of(context).pushNamed(MaintenanceRequestScreen.routeName);
                  },
                  'Maintenances',
                ),
                _buildItemCategory(
                  ImageHelper.loadFromAsset(AssetHelper.imageServiceButton),
                      () {
                    Navigator.of(context).pushNamed(ServicesScreen.routeName);
                  },
                  'Services',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
