import 'package:flutter/material.dart';
import '../../core/service/api_service.dart';
import '../widgets/app_bar_container.dart';

class AddServiceScreen extends StatefulWidget {
  const AddServiceScreen({super.key});

  static const routeName = '/add_service_screen';

  @override
  State<AddServiceScreen> createState() => _AddServiceScreenState();
}

class _AddServiceScreenState extends State<AddServiceScreen> {
  final ApiService apiService = ApiService();
  final _formKey = GlobalKey<FormState>();

  String _serviceName = ''; // Tên dịch vụ
  String _description = ''; // Mô tả
  String _price = ''; // Giá dịch vụ

  // Hàm gọi API để thêm dịch vụ
  Future<void> _createService() async {
    if (_formKey.currentState?.validate() ?? false) {
      try {
        final success = await apiService.createService(
          _serviceName,
          _description,
          _price,
        );
        if (success) {
          Navigator.of(context).pop(true);
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Thêm dịch vụ thành công')),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Không thể thêm dịch vụ')),
          );
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Lỗi khi thêm dịch vụ: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Thêm dịch vụ mới',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 16.0),
            Form(
              key: _formKey,
              child: Column(
                children: [
                  // Tên dịch vụ
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Tên Dịch Vụ'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Vui lòng nhập tên dịch vụ';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      _serviceName = value;
                    },
                  ),
                  const SizedBox(height: 16.0),
                  // Mô tả
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Mô Tả'),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Vui lòng nhập mô tả';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      _description = value;
                    },
                  ),
                  const SizedBox(height: 16.0),
                  // Giá dịch vụ
                  TextFormField(
                    decoration: const InputDecoration(labelText: 'Giá Dịch Vụ'),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Vui lòng nhập giá dịch vụ';
                      }
                      if (double.tryParse(value) == null) {
                        return 'Giá dịch vụ không hợp lệ';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      _price = value;
                    },
                  ),
                  const SizedBox(height: 32.0),
                  ElevatedButton(
                    onPressed: _createService,
                    child: const Text('Thêm Dịch Vụ'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
