import 'package:flutter/material.dart';
import 'package:hotel_ui_app/representation/screens/add_services_screen.dart';
import 'package:hotel_ui_app/representation/screens/using_service_screen.dart';

import '../../core/constant/color_constant.dart';
import '../../core/constant/dismension_constant.dart';
import '../../core/service/api_service.dart';
import '../widgets/app_bar_container.dart';
import '../widgets/item_services_widget.dart'; // Import widget mới

class ServicesScreen extends StatefulWidget {
  const ServicesScreen({super.key});

  static const routeName = '/services_screen';

  @override
  State<ServicesScreen> createState() => _ServicesScreenState();
}

class _ServicesScreenState extends State<ServicesScreen> {
  final ApiService apiService = ApiService();
  List<dynamic> services = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchServices();
  }

  Future<void> fetchServices() async {
    try {
      final data = await apiService.fetchAllServices();
      setState(() {
        services = data;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  // Hàm gọi API xóa
  Future<void> deleteService(int serviceId) async {
    try {
      final success = await apiService.deleteService(serviceId);
      if (success) {
        fetchServices();
        setState(() {
          services.removeWhere((item) => item['id'] == serviceId);  // Xóa dịch vụ khỏi danh sách
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Dịch vụ đã được xóa')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Không thể xóa dịch vụ')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi khi xóa dịch vụ: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: Column(
        children: [
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : services.isEmpty
                ? const Center(child: Text('Không có dịch vụ nào để hiển thị'))
                : ListView.builder(
              itemCount: services.length,
              itemBuilder: (context, index) {
                final service = services[index];
                final price = double.tryParse(service['GiaDichVu'] ?? '0') ?? 0.0;
                final serviceId = service['MaDichVu'];

                return GestureDetector(
                  onTap: (){
                    Navigator.of(context).pop({
                      'id': service['MaDichVu'].toString(),
                      'name': service['TenDichVu']
                    });
                  },
                  onLongPress: () {
                    // Hiển thị dialog xác nhận xóa
                    showDialog(
                      context: context,
                      builder: (context) {
                        return AlertDialog(
                          title: const Text('Xác nhận xóa'),
                          content: const Text('Bạn có chắc chắn muốn xóa dịch vụ này không?'),
                          actions: [
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop();  // Đóng dialog
                              },
                              child: const Text('Hủy'),
                            ),
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop();  // Đóng dialog
                                deleteService(serviceId);  // Gọi API xóa
                              },
                              child: const Text('Xóa'),
                            ),
                          ],
                        );
                      },
                    );
                  },
                  child: ItemServicesWidget(
                    icon: Icons.room_service,  // Bạn có thể thay đổi biểu tượng này
                    label: service['TenDichVu'] ?? 'No Name',
                    value: 'Giá: ${price > 0 ? price.toStringAsFixed(0) : 'Không rõ'} VND',
                    detail: {
                      'Mô tả': service['MoTa'] ?? 'Không có mô tả',  // Ví dụ mô tả
                    },
                  ),
                );
              },
            ),
          ),
          SizedBox(
            height: kDefaultPadding,
          ),
          SizedBox(
            width: double.infinity, // Đặt chiều rộng nút chiếm toàn bộ chiều ngang
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(context).pushNamed(AddServiceScreen.routeName);
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor: ColorPalette.buttonColor, // Tăng padding cho nút
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                shadowColor: Colors.black.withOpacity(0.25), // Màu bóng đổ
                elevation: 8, // Độ nổi của nút
              ),
              child: const Text(
                "Thêm Dịch Vụ Mới",
                style: TextStyle(
                  fontSize: 18, // Kích thước chữ
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ),

          // Nút Đăng ký ngoài danh sách
          SizedBox(
            height: kDefaultPadding,
          ),
          SizedBox(
            width: double.infinity, // Đặt chiều rộng nút chiếm toàn bộ chiều ngang
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(context).pushNamed(UsingServicesScreen.routeName);
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor: ColorPalette.buttonColor, // Tăng padding cho nút
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                shadowColor: Colors.black.withOpacity(0.25), // Màu bóng đổ
                elevation: 8, // Độ nổi của nút
              ),
              child: const Text(
                "Xem Các Lượt Sử Dụng Dịch Vụ",
                style: TextStyle(
                  fontSize: 18, // Kích thước chữ
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
