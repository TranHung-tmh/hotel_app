import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';
import '../../core/constant/color_constant.dart';
import '../../core/constant/dismension_constant.dart';
import '../widgets/app_bar_container.dart';
import 'booking_screen.dart';

class SelectDateScreen extends StatelessWidget {
  static const String routeName = '/select_date_screen';

  DateTime? rangeStartDay;
  DateTime? rangeEndDay;

  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: Container(
        child: Column(
          children: [
            SizedBox(height: kMediumPadding * 1.5),
            SfDateRangePicker(
              view: DateRangePickerView.month,
              selectionMode: DateRangePickerSelectionMode.range,
              monthViewSettings: DateRangePickerMonthViewSettings(
                firstDayOfWeek: 1,
              ),
              selectionColor: ColorPalette.thirdColor,
              startRangeSelectionColor: ColorPalette.thirdColor,
              endRangeSelectionColor: ColorPalette.thirdColor,
              rangeSelectionColor: ColorPalette.thirdColor,
              todayHighlightColor: ColorPalette.thirdColor,
              toggleDaySelection: true,
              onSelectionChanged: (DateRangePickerSelectionChangedArgs args) {
                if (args.value is PickerDateRange) {
                  rangeStartDay = args.value.startDay;
                  rangeEndDay = args.value.endDay;
                }
              },
            ),
            SizedBox(
              width: 400,
              child: ElevatedButton(
                onPressed: () {
                  if (rangeStartDay != null && rangeEndDay != null) {
                    String formattedRange = "${rangeStartDay!.toLocal()} - ${rangeEndDay!.toLocal()}";
                    Navigator.of(context).pop(formattedRange);  // Trả lại chuỗi ngày đã chọn
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Vui lòng chọn ngày')),
                    );
                  }
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: ColorPalette.buttonColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  shadowColor: Colors.black.withOpacity(0.25),
                  elevation: 8,
                ),
                child: const Text(
                  "Select",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            SizedBox(height: kDefaultPadding),
            SizedBox(
              width: 400,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pushNamed(BookingScreen.routeName);
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: ColorPalette.buttonColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  shadowColor: Colors.black.withOpacity(0.25),
                  elevation: 8,
                ),
                child: const Text(
                  "Cancel",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
