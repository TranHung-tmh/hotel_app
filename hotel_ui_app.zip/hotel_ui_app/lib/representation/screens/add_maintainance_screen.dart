import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hotel_ui_app/representation/screens/list_booking_screen.dart';
import '../../core/constant/color_constant.dart';
import '../../core/constant/dismension_constant.dart';
import '../../core/service/api_service.dart';
import '../widgets/app_bar_container.dart';
import '../widgets/item_booking_widget.dart';
import 'profile_screen.dart';
import 'rooms_screen.dart';

class AddMaintainanceScreen extends StatefulWidget {
  const AddMaintainanceScreen({Key? key}) : super(key: key);

  static const routeName = '/add_maintainance_screen';

  @override
  State<AddMaintainanceScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<AddMaintainanceScreen> {
  final ApiService apiService = ApiService();
  String? selectedRoomId;
  String selectedRoomName = "Chưa chọn phòng";
  DateTime? sendDate ;
  DateTime? completedDate;


  Future<void> _createMaintainance() async {
    if (selectedRoomId == null ||
        sendDate == null ||
        completedDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Vui lòng chọn đầy đủ thông tin!")),
      );
      return;
    }
    bool success = await apiService.createMaintenanceRequest(
      selectedRoomId!,
      sendDate!,
      completedDate!,
    );

    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Thêm lượt bảo trì thành công!")),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Thêm lượt bảo trì thất bại!")),
      );
    }
  }



  Future<void> _selectSendDate() async {
    final DateTime? selected = await showDatePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
      initialDate: DateTime.now(),
    );

    if (selected != null) {
      setState(() {
        sendDate = selected;
      });
    }
  }

  Future<void> _selectCompletedDate() async {
    final DateTime? selected = await showDatePicker(
      context: context,
      firstDate: sendDate!,
      lastDate: DateTime(2100),
      initialDate: sendDate ?? DateTime.now(), // Đặt giá trị mặc định là checkInDate nếu đã chọn
    );

    if (selected != null && selected.isAfter(sendDate!)) {
      setState(() {
        completedDate = selected;
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Ngày trả phòng phải sau ngày nhận phòng")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ItemBookingWidget(
              icon: Icons.bed,
              label: "Thông Tin Phòng:",
              value: selectedRoomName != null
                  ? '[$selectedRoomId] $selectedRoomName'
                  : 'Chon Phong',
              onTap: () async {
                final result = await Navigator.of(context).pushNamed(RoomsScreen.routeName);
                if (result != null && result is Map) {
                  setState(() {
                    selectedRoomId = result['id'] ?? '';
                    selectedRoomName = result['name'] ?? '';
                  });
                }
              },
            ),
            ItemBookingWidget(
              icon: Icons.calendar_today,
              label: "Ngày nhận phòng:",
              value: sendDate == null
                  ? "Chưa chọn"
                  : "${sendDate!.day}/${sendDate!.month}/${sendDate!.year}",
              onTap: _selectSendDate,
            ),
            ItemBookingWidget(
              icon: Icons.calendar_today,
              label: "Ngày trả phòng:",
              value: completedDate == null
                  ? "Chưa chọn"
                  : "${completedDate!.day}/${completedDate!.month}/${completedDate!.year}",
              onTap: _selectCompletedDate,
            ),

            SizedBox(height: kDefaultPadding),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _createMaintainance,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: ColorPalette.buttonColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  shadowColor: Colors.black.withOpacity(0.25),
                  elevation: 8,
                ),
                child: const Text(
                  "Thêm Lượt Bảo Trì",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
