import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import '../../core/service/api_service.dart';
import '../widgets/app_bar_container.dart';
import '../widgets/item_feedback_widget.dart';
import '../widgets/item_list_booking_widget.dart';


class ListBookingScreen extends StatefulWidget {
  const ListBookingScreen({Key? key}) : super(key: key);

  static const routeName = '/list_booking_screen';

  @override
  State<ListBookingScreen> createState() => _ListBookingScreenState();
}

class _ListBookingScreenState extends State<ListBookingScreen> {
  final ApiService apiService = ApiService();
  List<dynamic> bookings = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchBookingList();
  }

  Future<void> fetchBookingList() async {
    try {
      final data = await apiService.fetchAllBooking();
      setState(() {
        bookings = data;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  Future<void> deleteBooking(int bookingId) async {
    try {
      final success = await apiService.deleteBooking(bookingId);
      if (success) {
        fetchBookingList();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Lượt đặt phòng đã được xóa')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Không thể xóa lượt đặt phòng')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi khi xóa lượt đặt phòng: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: Column(
        children: [
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : bookings.isEmpty
                ? const Center(child: Text('Không có để hiển thị'))
                : ListView.builder(
              itemCount: bookings.length,
              itemBuilder: (context, index) {
                final booking = bookings[index];
                final bookingId = booking['MaDatPhong'];
                final customerName = booking['KhachHang']['Ten'] ??
                    'Không rõ tên khách hàng';
                final roomName = booking['Phong']['SoPhong'].toString() ?? 'Không có nội dung';

                return GestureDetector(
                  onLongPress: () {
                    // Hiển thị dialog xác nhận xóa
                    showDialog(
                      context: context,
                      builder: (context) {
                        return AlertDialog(
                          title: const Text('Xác nhận xóa'),
                          content: const Text(
                              'Bạn có chắc chắn muốn xóa phản hồi này không?'),
                          actions: [
                            TextButton(
                              onPressed: () {
                                Navigator.of(context)
                                    .pop(); // Đóng dialog nếu hủy
                              },
                              child: const Text('Hủy'),
                            ),
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop(); // Đóng dialog
                                deleteBooking(bookingId); // Gọi API xóa
                              },
                              child: const Text('Xóa'),
                            ),
                          ],
                        );
                      },
                    );
                  },
                  child: ItemListBookingWidget(
                    icon: FontAwesomeIcons.hotel,
                    madat: 'Mã Đặt Phòng : $bookingId',
                    khachhang: 'Khách Hàng: $customerName',
                    sophong: 'Phòng: $roomName',
                    backgroundColor: Colors.white,
                    detail: {
                      'Ngày Đặt Phòng': booking['NgayDat'] ?? 'Không rõ ngày đặt',
                      'Ngày Nhận Phòng': booking['NgayNhan'] ?? 'Không rõ ngày nhận',
                      'Ngày Trả Phòng': booking['NgayTra'] ?? 'Không rõ ngày trả',
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}