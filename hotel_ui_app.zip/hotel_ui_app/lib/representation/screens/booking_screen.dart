import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hotel_ui_app/representation/screens/list_booking_screen.dart';
import '../../core/constant/color_constant.dart';
import '../../core/constant/dismension_constant.dart';
import '../../core/service/api_service.dart';
import '../widgets/app_bar_container.dart';
import '../widgets/item_booking_widget.dart';
import 'profile_screen.dart';
import 'rooms_screen.dart';

class BookingScreen extends StatefulWidget {
  const BookingScreen({Key? key}) : super(key: key);

  static const routeName = '/booking_screen';

  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen> {
  final ApiService apiService = ApiService();
  String? selectedCustomerId;
  String? selectedRoomId;
  String selectedCustomerName = "Chưa chọn khách hàng";
  String selectedRoomName = "Chưa chọn phòng";
  String bookingDates = "Chưa chọn ngày";
  DateTime? bookingDate ;
  DateTime? checkInDate;
  DateTime? checkOutDate;


  Future<void> _createBookingRoom() async {
    if (selectedCustomerId == null ||
        selectedRoomId == null ||
        checkInDate == null ||
        checkOutDate == null ||
        bookingDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Vui lòng chọn đầy đủ thông tin!")),
      );
      return;
    }
    bool success = await apiService.createBookingRoom(
      selectedCustomerId!,
      selectedRoomId!,
      checkInDate!,
      bookingDate!,
      checkOutDate!,
    );

    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Đặt phòng thành công!")),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Đặt phòng thất bại!")),
      );
    }
  }



  Future<void> _selectBookingDate() async {
    final DateTime? selected = await showDatePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
      initialDate: bookingDate ?? DateTime.now(),
    );

    if (selected != null) {
      setState(() {
        bookingDate = selected;
      });
    }
  }

  Future<void> _selectCheckInDate() async {
    final DateTime? selected = await showDatePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
      initialDate: checkInDate ?? DateTime.now(), // Đặt giá trị mặc định là checkInDate nếu đã chọn
    );

    if (selected != null) {
      setState(() {
        // Nếu ngày trả phòng đã có và ngày nhận phòng chọn sau ngày trả phòng thì xóa ngày trả phòng
        checkInDate = selected;
        if (checkOutDate != null && selected.isAfter(checkOutDate!)) {
          checkOutDate = null;
        }
      });
    }
  }
  Future<void> _selectCheckOutDate() async {
    if (checkInDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Vui lòng chọn ngày nhận phòng trước")),
      );
      return;
    }

    final DateTime? selected = await showDatePicker(
      context: context,
      firstDate: checkInDate!, // Ngày trả phòng phải là sau hoặc cùng ngày nhận phòng
      lastDate: DateTime(2100),
      initialDate: checkInDate!, // Ngày mặc định là ngày nhận phòng
    );

    if (selected != null && selected.isAfter(checkInDate!)) {
      setState(() {
        checkOutDate = selected;
        bookingDates =
        "${checkInDate!.day}/${checkInDate!.month}/${checkInDate!.year} - ${checkOutDate!.day}/${checkOutDate!.month}/${checkOutDate!.year}";
      });
    } else {
      // Nếu chọn ngày trả phòng không hợp lệ
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Ngày trả phòng phải sau ngày nhận phòng")),
      );
    }
  }
  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ItemBookingWidget(
              icon: FontAwesomeIcons.solidUser,
              label: "Thông tin khách hàng: ",
              value: selectedCustomerName != null
                  ? '[$selectedCustomerId] $selectedCustomerName'
                  : 'Chọn khách hàng',
              onTap: () async {
                final result = await Navigator.of(context).pushNamed(ProfileScreen.routeName);
                if (result != null && result is Map) {
                  setState(() {
                    selectedCustomerId = result['id'] ?? '';
                    selectedCustomerName = result['name'] ?? '';
                  });
                }
              },
            ),

            ItemBookingWidget(
              icon: Icons.bed,
              label: "Thông Tin Phòng:",
              value: selectedRoomName != null
                  ? '[$selectedRoomId] $selectedRoomName'
                  : 'Chon Phong',
              onTap: () async {
                final result = await Navigator.of(context).pushNamed(RoomsScreen.routeName);
                if (result != null && result is Map) {
                  setState(() {
                    selectedRoomId = result['id'] ?? '';
                    selectedRoomName = result['name'] ?? '';
                  });
                }
              },
            ),
            ItemBookingWidget(
              icon: Icons.calendar_today,
              label: "Ngày đặt phòng",
              value: bookingDate == null
                  ? "Chưa chọn"
                  : "${bookingDate!.day}/${bookingDate!.month}/${bookingDate!.year}",
              onTap: _selectBookingDate,
            ),
            ItemBookingWidget(
              icon: Icons.calendar_today,
              label: "Ngày nhận phòng:",
              value: checkInDate == null
                  ? "Chưa chọn"
                  : "${checkInDate!.day}/${checkInDate!.month}/${checkInDate!.year}",
              onTap: _selectCheckInDate,
            ),
            ItemBookingWidget(
              icon: Icons.calendar_today,
              label: "Ngày trả phòng:",
              value: checkOutDate == null
                  ? "Chưa chọn"
                  : "${checkOutDate!.day}/${checkOutDate!.month}/${checkOutDate!.year}",
              onTap: _selectCheckOutDate,
            ),

            SizedBox(height: kDefaultPadding),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _createBookingRoom,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: ColorPalette.buttonColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  shadowColor: Colors.black.withOpacity(0.25),
                  elevation: 8,
                ),
                child: const Text(
                  "Thêm Lượt Đặt Phòng",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            SizedBox(height: kDefaultPadding),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed:()
                {
                  Navigator.of(context).pushNamed(ListBookingScreen.routeName);
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: ColorPalette.buttonColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  shadowColor: Colors.black.withOpacity(0.25),
                  elevation: 8,
                ),
                child: const Text(
                  "Xem Lượt Đặt Phòng",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
