import 'package:flutter/material.dart';
import 'package:hotel_ui_app/representation/screens/add_room_screen.dart';
import '../../core/constant/color_constant.dart';
import '../../core/constant/dismension_constant.dart';
import '../../core/service/api_service.dart';
import '../widgets/app_bar_container.dart';
import '../widgets/item_rooms_widget.dart';

class RoomsScreen extends StatefulWidget {
  const RoomsScreen({super.key});

  static const routeName = '/rooms_screen';

  @override
  State<RoomsScreen> createState() => _RoomsScreenState();
}

class _RoomsScreenState extends State<RoomsScreen> {
  final ApiService apiService = ApiService();
  List<dynamic> rooms = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchRooms();
  }

  Future<void> fetchRooms() async {
    try {
      final data = await apiService.fetchAllRooms();
      setState(() {
        rooms = data;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  // Hàm gọi API xóa
  Future<void> deleteRoom(int roomId) async {
    try {
      final success = await apiService.deleteRooms(roomId);
      if (success) {
        fetchRooms();
        setState(() {
          rooms.removeWhere((item) => item['id'] == roomId);  // Xóa phòng khỏi danh sách
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Phòng đã được xóa')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Không thể xóa phòng')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi khi xóa phòng: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: Column(
        children: [
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : rooms.isEmpty
                ? const Center(child: Text('Không có phòng nào để hiển thị'))
                : ListView.builder(
              itemCount: rooms.length,
              itemBuilder: (context, index) {
                final room = rooms[index];
                final price = room['GiaPhong'] ?? 'Không rõ giá';
                final roomId = room['MaPhong'];

                return GestureDetector(
                  onTap: (){
                    Navigator.of(context).pop({
                      'id': room['MaPhong'].toString(), // Chuyển đổi mã khách hàng sang chuỗi
                      'name': room['LoaiPhong']
                    });
                  },
                  onLongPress: () {
                    // Hiển thị dialog xác nhận xóa
                    showDialog(
                      context: context,
                      builder: (context) {
                        return AlertDialog(
                          title: const Text('Xác nhận xóa'),
                          content: const Text('Bạn có chắc chắn muốn xóa phòng này không?'),
                          actions: [
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop();  // Đóng dialog
                              },
                              child: const Text('Hủy'),
                            ),
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop();  // Đóng dialog
                                deleteRoom(roomId);  // Gọi API xóa
                              },
                              child: const Text('Xóa'),
                            ),
                          ],
                        );
                      },
                    );
                  },
                  child: RoomItemWidget(
                    roomType: room['LoaiPhong'] ?? 'Không rõ loại phòng',
                    roomNumber: room['SoPhong'] ?? 'Không rõ phòng',
                    roomPrice: price,
                  ),
                );
              },
            ),
          ),
          SizedBox(
            height: kMediumPadding,
          ),
          SizedBox(
            width: double.infinity, // Đặt chiều rộng nút chiếm toàn bộ chiều ngang
            child: ElevatedButton(
              onPressed: () {
                Navigator.of(context).pushNamed(AddRoomScreen.routeName);
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor: ColorPalette.buttonColor, // Tăng padding cho nút
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                shadowColor: Colors.black.withOpacity(0.25), // Màu bóng đổ
                elevation: 8, // Độ nổi của nút
              ),
              child: const Text(
                "Thêm Phòng Mới",
                style: TextStyle(
                  fontSize: 18, // Kích thước chữ
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
