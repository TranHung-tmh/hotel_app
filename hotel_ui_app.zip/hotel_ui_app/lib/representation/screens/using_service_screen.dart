import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hotel_ui_app/representation/screens/add_using_service_screen.dart';
import 'package:hotel_ui_app/representation/widgets/app_bar_container.dart';
import 'package:hotel_ui_app/representation/widgets/item_using_service_widget.dart';
import '../../core/constant/color_constant.dart';
import '../../core/constant/dismension_constant.dart';
import '../../core/service/api_service.dart';
import '../widgets/item_services_widget.dart';  // Import widget mới

class UsingServicesScreen extends StatefulWidget {
  const UsingServicesScreen({Key? key}) : super(key: key);

  static const routeName = '/using_services_screen';

  @override
  State<UsingServicesScreen> createState() => _UsingServicesScreenState();
}

class _UsingServicesScreenState extends State<UsingServicesScreen> {
  final ApiService apiService = ApiService();
  List<dynamic> using = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchUsingServices();
  }

  Future<void> fetchUsingServices() async {
    try {
      final data = await apiService.fetchAllUsingServices();
      setState(() {
        using = data; // Cập nhật lại dữ liệu
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }



  Future<void> _updateServiceStatus(int usingId, String status) async {
    try {
      print('Start updating service status...');
      print('UsingId: $usingId, Status: $status');

      await apiService.updateTrangThai(usingId, status);

      print('Update successful. Fetching updated services...');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Cập nhật trạng thái thành công: $status')),
      );

      fetchUsingServices(); // Cập nhật lại danh sách
      print('Fetch completed.');
    } catch (e) {
      print('Error occurred: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi khi cập nhật trạng thái: $e')),
      );
    }
  }




  Future<void> deleteUsingService(int usingId) async {
    try {
      final success = await apiService.deleteServiceUsage(usingId);
      if (success) {
        fetchUsingServices();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Thông tin sử dụng dịch vụ đã được xóa')),
        );
      } else {
        print("Không thể xóa dịch vụ với ID: $usingId");
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Không thể xóa thông tin sử dụng dịch vụ')),
        );
      }
    } catch (e) {
      print("Lỗi khi xóa dịch vụ: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi khi xóa thông tin sử dụng dịch vụ: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
        child: Column(
          children: [
            Expanded(child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : using.isEmpty
                ? const Center(child: Text('Không có lượt nào để hiển thị'))
                : ListView.builder(
              itemCount: using.length,
              itemBuilder: (context, index) {
                final usings = using[index];
                final usingId = usings['MaSuDungDv'];
                final serviceName = usings['DichVu']?['TenDichVu'] ?? 'Không rõ tên dịch vụ';
                final customerName = usings['KhachHang']?['Ten'] ?? 'Không rõ tên khách hàng';
                final quantity = usings['SoLuong'] ?? 'Không có số lượng';
                final totalAmount = usings['TongTien'] ?? 'Không rõ';
                final note = usings['ghiChu'] ?? 'Khong Co';
                final status = usings['TrangThai'] ?? 'Khong ro';
                return GestureDetector(
                  onLongPress: ()
                  {
                    showDialog(
                      context: context,
                      builder: (context) {
                        return AlertDialog(
                          title: const Text('Xác nhận xóa'),
                          content: const Text('Bạn có chắc chắn muốn xóa dịch vụ này không?'),
                          actions: [
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop();  // Đóng dialog
                              },
                              child: const Text('Hủy'),
                            ),
                            TextButton(
                              onPressed: () {
                                print("Bấm nút Xóa, gọi hàm deleteUsingService với ID: $usingId");
                                Navigator.of(context).pop();
                                deleteUsingService(usingId);
                              },
                              child: const Text('Xóa'),
                            ),
                          ],
                        );
                      },
                    );
                  },
                  child: ItemUsingServiceWidget(
                    icon: FontAwesomeIcons.bellConcierge,  // Biểu tượng có thể thay đổi
                    label: serviceName,
                    value: 'Khách Hàng: $customerName',
                    detail: {
                      'Tổng Tiền': '$totalAmount VND',
                      'Số Lượng': '$quantity lần',
                      'Ghi Chu': '$note' ,
                      'Trang Thai': '$status',
                    },
                    onAccept: (){
                      _updateServiceStatus(usingId, "Duyệt");
                    },
                    onReject: (){
                      _updateServiceStatus(usingId, "Từ Chối");
                    },
                  ),
                );
              },
            ),
            ),
            SizedBox(
              height: kMediumPadding,
            ),
            SizedBox(
              width: double.infinity, // Đặt chiều rộng nút chiếm toàn bộ chiều ngang
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pushNamed(AddUsingServiceScreen.routeName);
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: ColorPalette.buttonColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  shadowColor: Colors.black.withOpacity(0.25),
                  elevation: 8,
                ),
                child: const Text(
                  "Thêm Lượt Sử Dụng Dịch Vụ Mới",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            )
          ],
        )
    );
  }
}
