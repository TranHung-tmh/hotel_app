import 'dart:js_interop';

import 'package:flutter/material.dart';
import 'package:hotel_ui_app/core/constant/dismension_constant.dart';
import 'package:hotel_ui_app/core/constant/textstyle_constants.dart';

class ButtonWidget extends StatelessWidget {
  final String title; // Text hiển thị trên button
  final VoidCallback onTap; // Hành động khi nhấn

  const ButtonWidget({
    Key? key,
    required this.title,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: kDefaultPadding),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(kDefaultPadding),
      ),
      child: Text(
        title,
        style: AppStyles.buttonText,
      ),
    );
  }
}
