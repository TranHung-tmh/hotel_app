import 'package:flutter/material.dart';
import 'package:hotel_ui_app/core/constant/color_constant.dart';

import '../screens/stundent_info_screen.dart';

class AppBarContainer extends StatelessWidget {
  final Widget child;

  const AppBarContainer({Key? key, required this.child}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Gradient Background với bo góc
          ClipRRect(
            borderRadius: const BorderRadius.only(
              bottomLeft: Radius.circular(35),
              bottomRight: Radius.circular(35),
            ),
            child: Container(
              height: 186,
              width: double.infinity,
              decoration: const BoxDecoration(
                gradient: Gradients.defaultGradientBackground,
              ),
            ),
          ),
          // Nội dung của AppBar
          Padding(
            padding: const EdgeInsets.only(top: 50, left: 20, right: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Logo và các nút bên cạnh
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: Icon(Icons.arrow_back, size: 30, color: Colors.white),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    )
                    ,
                    Text(
                      "TMHUNG Hotel", // Tên logo
                      style: TextStyle(
                        fontSize: 24,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.settings, size: 30, color: Colors.white),
                      onPressed: () {
                        Navigator.of(context).pushNamed(StundentInfoScreen.routeName);
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                // Thanh tìm kiếm
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.search, color: ColorPalette.primaryColor),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextField(
                          decoration: InputDecoration(
                            hintText: "Search",
                            border: InputBorder.none,
                            hintStyle: TextStyle(
                              color: Colors.grey.shade500,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ),
                      Icon(Icons.tune, color: ColorPalette.primaryColor),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // Nội dung bên dưới AppBar
          Positioned.fill(
            top: 186, // Khoảng cách dưới AppBar
            child: Container(
              color: Colors.white,
              child: child, // Thêm nội dung từ `child`
            ),
          ),
        ],
      ),
    );
  }
}
