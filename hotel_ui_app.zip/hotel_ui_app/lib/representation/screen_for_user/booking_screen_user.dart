import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hotel_ui_app/representation/screen_for_user/profile_screen_user.dart';
import 'package:hotel_ui_app/representation/screens/list_booking_screen.dart';
import 'package:hotel_ui_app/representation/screens/rooms_screen.dart';
import '../../core/constant/color_constant.dart';
import '../../core/constant/dismension_constant.dart';
import '../../core/service/api_service.dart';
import '../widgets/app_bar_container.dart';
import '../widgets/item_booking_widget.dart';
import '../../core/helper/shared_preferences_helper.dart';

class BookingScreenUser extends StatefulWidget {
  const BookingScreenUser({Key? key}) : super(key: key);

  static const routeName = '/booking_screen_user';

  @override
  State<BookingScreenUser> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreenUser> {
  final ApiService apiService = ApiService();
  String? selectedCustomerId;
  String? selectedRoomId;
  String selectedRoomName = "Chưa chọn phòng";
  String bookingDates = "Chưa chọn ngày";
  DateTime bookingDate = DateTime.now();
  DateTime? checkInDate;
  DateTime? checkOutDate;
  String selectedCustomerName = "Chưa chọn khách hàng";

  @override
  void initState() {
    super.initState();
    _loadCustomerData();
  }

  // Lấy thông tin khách hàng từ SharedPreferences
  Future<void> _loadCustomerData() async {
    final customerId = await SharedPreferencesHelper.getCustomerId();
    final customerName = await SharedPreferencesHelper.getCustomerName();
    setState(() {
      selectedCustomerId = customerId;
      selectedCustomerName = customerName ?? "Chưa có tên";
    });
  }

  Future<void> _createBookingRoom() async {
    if (selectedRoomId == null || checkInDate == null || checkOutDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Vui lòng chọn đầy đủ thông tin!")),
      );
      return;
    }
    bool success = await apiService.createBookingRoom(
      selectedCustomerId!,
      selectedRoomId!,
      checkInDate!,
      bookingDate!,
      checkOutDate!,
    );

    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Đặt phòng thành công!")),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Đặt phòng thất bại!")),
      );
    }
  }



  Future<void> _selectCheckInDate() async {
    final DateTime? selected = await showDatePicker(
      context: context,
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
      initialDate: checkInDate ?? DateTime.now(),
    );

    if (selected != null) {
      setState(() {
        checkInDate = selected;
        if (checkOutDate != null && selected.isAfter(checkOutDate!)) {
          checkOutDate = null;
        }
      });
    }
  }

  Future<void> _selectCheckOutDate() async {
    if (checkInDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Vui lòng chọn ngày nhận phòng trước")),
      );
      return;
    }

    final DateTime? selected = await showDatePicker(
      context: context,
      firstDate: checkInDate!,
      lastDate: DateTime(2100),
      initialDate: checkInDate!,
    );

    if (selected != null && selected.isAfter(checkInDate!)) {
      setState(() {
        checkOutDate = selected;
        bookingDates =
        "${checkInDate!.day}/${checkInDate!.month}/${checkInDate!.year} - ${checkOutDate!.day}/${checkOutDate!.month}/${checkOutDate!.year}";
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Ngày trả phòng phải sau ngày nhận phòng")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ItemBookingWidget(
              icon: FontAwesomeIcons.solidUser,
              label: "Thông tin khách hàng: ",
              value: selectedCustomerName != null
                  ? '$selectedCustomerName': "Chưa tải",
            ),
            ItemBookingWidget(
              icon: Icons.bed,
              label: "Thông Tin Phòng:",
              value: selectedRoomName != null
                  ? '$selectedRoomName'
                  : 'Chọn phòng',
              onTap: () async {
                final result = await Navigator.of(context).pushNamed(RoomsScreen.routeName);
                if (result != null && result is Map) {
                  setState(() {
                    selectedRoomId = result['id'] ?? '';
                    selectedRoomName = result['name'] ?? '';
                  });
                }
              },
            ),
            ItemBookingWidget(
              icon: Icons.calendar_today,
              label: "Ngày nhận phòng:",
              value: checkInDate == null
                  ? "Chưa chọn"
                  : "${checkInDate!.day}/${checkInDate!.month}/${checkInDate!.year}",
              onTap: _selectCheckInDate,
            ),
            ItemBookingWidget(
              icon: Icons.calendar_today,
              label: "Ngày trả phòng:",
              value: checkOutDate == null
                  ? "Chưa chọn"
                  : "${checkOutDate!.day}/${checkOutDate!.month}/${checkOutDate!.year}",
              onTap: _selectCheckOutDate,
            ),
            SizedBox(height: kDefaultPadding),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _createBookingRoom,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: ColorPalette.buttonColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  shadowColor: Colors.black.withOpacity(0.25),
                  elevation: 8,
                ),
                child: const Text(
                  "Đặt Phòng",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
