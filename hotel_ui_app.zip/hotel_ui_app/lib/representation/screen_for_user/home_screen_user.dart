import 'package:flutter/material.dart';
import 'package:hotel_ui_app/core/helper/asset_helper.dart';
import 'package:hotel_ui_app/core/helper/image_helper.dart';
import 'package:hotel_ui_app/representation/screen_for_user/notifications_screen.dart';
import 'package:hotel_ui_app/representation/screen_for_user/room_screen_user.dart';
import 'package:hotel_ui_app/representation/screen_for_user/service_screen_user.dart';
import 'package:hotel_ui_app/representation/screens/maintenance_request_screen.dart';
import 'package:hotel_ui_app/representation/screens/rooms_screen.dart';
import 'package:hotel_ui_app/representation/screens/services_screen.dart';
import 'package:hotel_ui_app/representation/widgets/app_bar_container.dart';

class HomeScreenUser extends StatelessWidget {
  const HomeScreenUser({Key? key}) : super(key: key);

  static const routeName = '/home_screen_user';

  Widget _buildItemCategory(Widget img, Function() onTap, String title) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            height: 120,
            width: 120,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(15),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: img,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            title,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }

  Widget _buildPopularLocations() {
    final locations = [
      {"image": ImageHelper.loadFromAsset(AssetHelper.imageHaLong), "name": "Ha Long"},
      {"image": ImageHelper.loadFromAsset(AssetHelper.imageVungTau), "name": "Vung Tau"},
      {"image": ImageHelper.loadFromAsset(AssetHelper.imagePhuQuoc), "name": "Phu Quoc"},
      {"image": ImageHelper.loadFromAsset(AssetHelper.imageNhaTrang), "name": "Nha Trang"},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.0),
          child: Text(
            "Popular Locations",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
        ),
        const SizedBox(height: 12),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: locations.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
              childAspectRatio: 1, // Điều chỉnh tỉ lệ khung hình để phù hợp hơn
            ),
            itemBuilder: (context, index) {
              final location = locations[index];
              return ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Stack(
                  children: [
                    location["image"] as Widget,
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.5),
                          borderRadius: const BorderRadius.only(
                            bottomLeft: Radius.circular(15),
                            bottomRight: Radius.circular(15),
                          ),
                        ),
                        child: Text(
                          location["name"] as String,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }



  Widget _buildSpecialOffers() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.0),
          child: Text(
            "Special Offers",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 200, // Chiều cao của danh sách
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: 5, // Số lượng ưu đãi
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(left: 16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 150,
                      width: 150,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        image: DecorationImage(
                          image: AssetImage(AssetHelper.imageHaLong), // Thay hình ảnh
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      "Offer Details", // Nội dung ưu đãi
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Text(
                "Categories",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround, // Căn đều các mục
              children: [
                _buildItemCategory(
                  ImageHelper.loadFromAsset(AssetHelper.imageRoomsButton),
                      () {
                    Navigator.of(context).pushNamed(RoomScreenUser.routeName);
                  },
                  'Rooms',
                ),
                _buildItemCategory(
                  ImageHelper.loadFromAsset(AssetHelper.imageMaintenanceButton),
                      () {
                    Navigator.of(context).pushNamed(NotificationsScreen.routeName);
                  },
                  'Notifications',
                ),
                _buildItemCategory(
                  ImageHelper.loadFromAsset(AssetHelper.imageServiceButton),
                      () {
                    Navigator.of(context).pushNamed(ServiceScreenUser.routeName);
                  },
                  'Services',
                ),
              ],
            ),
            const SizedBox(height: 32),
            _buildPopularLocations(),
            const SizedBox(height: 32),
            _buildSpecialOffers(),
          ],
        ),
      ),
    );
  }
}
