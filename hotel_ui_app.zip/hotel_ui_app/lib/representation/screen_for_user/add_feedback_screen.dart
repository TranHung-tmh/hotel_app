import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hotel_ui_app/representation/screen_for_user/service_screen_user.dart';
import 'package:hotel_ui_app/representation/screens/list_booking_screen.dart';
import '../../core/constant/color_constant.dart';
import '../../core/constant/dismension_constant.dart';
import '../../core/helper/shared_preferences_helper.dart';
import '../../core/service/api_service.dart';
import '../widgets/app_bar_container.dart';
import '../widgets/item_booking_widget.dart';

class AddFeedbackScreen extends StatefulWidget {
  const AddFeedbackScreen({Key? key}) : super(key: key);

  static const routeName = '/add_feedback_screen';

  @override
  State<AddFeedbackScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<AddFeedbackScreen> {
  final _feedbackController = TextEditingController();
  final ApiService apiService = ApiService();
  String? selectedCustomerId ;
  String? selectedCustomerName;
  String? selectedServiceId;
  String? selectedServiceName;
  String? comment ;
  DateTime sendDate = DateTime.now() ;
  String? type;

  @override
  void initState() {
    super.initState();
    _loadCustomerData();
  }

  Future<void> _loadCustomerData() async {

    final customerId = await SharedPreferencesHelper.getCustomerId();
    final customerName = await SharedPreferencesHelper.getCustomerName();
    setState(() {
      selectedCustomerId = customerId;
      selectedCustomerName = customerName ?? "Chưa có tên";
    });
  }

  Future<void> _createFeedback() async {
    comment = _feedbackController.text;

    if (selectedCustomerId == null ||
        selectedServiceId == null ||
        comment == null || comment!.isEmpty ||
        type == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Vui lòng chọn đầy đủ thông tin!")),
      );
      return;
    }

    try {
      bool success = await apiService.createFeedback(
        selectedCustomerId!,
        selectedServiceId!,
        comment!,
        sendDate,
        type!,
      );

      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Thêm phản hồi thành công!")),
        );
        Navigator.of(context).pop();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Thêm phản hồi thất bại. ")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Lỗi: ${e.toString()}")),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ItemBookingWidget(
              icon: FontAwesomeIcons.solidUser,
              label: "Thông tin khách hàng: ",
              value: selectedCustomerName != null
                  ? '$selectedCustomerName': "Chưa tải",
            ),
            ItemBookingWidget(
              icon: Icons.room_service,
              label: "Dịch vụ:",
              value: selectedServiceName != null
                  ? '$selectedServiceName'
                  : 'Chọn dịch vụ',
              onTap: () async {
                final result = await Navigator.of(context).pushNamed(ServiceScreenUser.routeName);
                if (result != null && result is Map) {
                  setState(() {
                    selectedServiceId = result['id'] ?? '';
                    selectedServiceName = result['name'] ?? '';
                  });
                }
              },
            ),
            // Loại phản hồi
            const Text(
              "Loại phản hồi:",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            DropdownButtonFormField<String>(
              value: type,
              decoration: const InputDecoration(border: OutlineInputBorder()),
              items: ["Phản hồi tích cực", "Phản hồi tiêu cực", "Khác"]
                  .map((type) => DropdownMenuItem(
                value: type,
                child: Text(type),
              ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  type = value!;
                });
              },
            ),
            const SizedBox(height: 16),

            // Nội dung phản hồi
            const Text(
              "Nội dung phản hồi:",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            TextFormField(
              controller: _feedbackController,
              maxLines: 4,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Nhập nội dung phản hồi tại đây...',
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Vui lòng nhập nội dung phản hồi!';
                }
                return null;
              },
            ),
            const SizedBox(height: 16),
            SizedBox(height: kDefaultPadding),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _createFeedback,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: ColorPalette.buttonColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  shadowColor: Colors.black.withOpacity(0.25),
                  elevation: 8,
                ),
                child: const Text(
                  "Thêm Phản Hồi",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
