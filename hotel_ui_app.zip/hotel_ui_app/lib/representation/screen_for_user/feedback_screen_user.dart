import 'package:flutter/material.dart';
import 'package:hotel_ui_app/representation/screen_for_user/add_feedback_screen.dart';
import 'package:hotel_ui_app/representation/widgets/app_bar_container.dart';

import '../../core/constant/color_constant.dart';
import '../../core/constant/dismension_constant.dart';
import '../../core/service/api_service.dart';
import '../widgets/item_feedback_widget.dart';

class FeedbackScreenUser extends StatefulWidget {
  const FeedbackScreenUser({Key? key}) : super(key: key);

  static const routeName = '/feedback_screen_user';

  @override
  State<FeedbackScreenUser> createState() => _FeedbackScreenState();
}

class _FeedbackScreenState extends State<FeedbackScreenUser> {
  final ApiService apiService = ApiService();
  List<dynamic> feedbacks = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchFeedbacks();
  }

  Future<void> fetchFeedbacks() async {
    try {
      final data = await apiService.fetchAllFeedBack();
      setState(() {
        feedbacks = data;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  Future<void> deleteFeedback(int fbId) async {
    try {
      final success = await apiService.deleteFeedBack(fbId);
      if (success) {
        // Refresh the list of feedbacks after deletion
        fetchFeedbacks();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Phản hồi đã được xóa')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Không thể xóa phản hồi')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi khi xóa phản hồi: $e')),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: Column(
        children: [
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : feedbacks.isEmpty
                ? const Center(child: Text('Không có phản hồi nào để hiển thị'))
                : ListView.builder(
              itemCount: feedbacks.length,
              itemBuilder: (context, index) {
                final feedback = feedbacks[index];
                final feedbackId = feedback['MaPhanHoi'];
                final customerName = feedback['KhachHang']['Ten'] ??
                    'Không rõ tên khách hàng';
                final feedbackContent = feedback['NoiDung'] ??
                    'Không có nội dung';

                return GestureDetector(
                  onLongPress: () {
                    // Hiển thị dialog xác nhận xóa
                    showDialog(
                      context: context,
                      builder: (context) {
                        return AlertDialog(
                          title: const Text('Xác nhận xóa'),
                          content: const Text(
                              'Bạn có chắc chắn muốn xóa phản hồi này không?'),
                          actions: [
                            TextButton(
                              onPressed: () {
                                Navigator.of(context)
                                    .pop(); // Đóng dialog nếu hủy
                              },
                              child: const Text('Hủy'),
                            ),
                            TextButton(
                              onPressed: () {
                                Navigator.of(context).pop(); // Đóng dialog
                                deleteFeedback(feedbackId); // Gọi API xóa
                              },
                              child: const Text('Xóa'),
                            ),
                          ],
                        );
                      },
                    );
                  },
                  child: FeedbackItemWidget(
                    icon: Icons.comment,
                    label: customerName,
                    value: feedbackContent,
                    backgroundColor: Colors.white,
                    detail: {
                      'Dịch vụ': feedback['DichVu']['TenDichVu'] ??
                          'Không rõ dịch vụ',
                      'Loại phản hồi': feedback['LoaiPh'] ?? 'Không rõ',
                    },
                  ),
                );
              },
            ),
          ),
          SizedBox(height: kDefaultPadding),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: (){
                Navigator.of(context).pushNamed(AddFeedbackScreen.routeName);
              },
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                backgroundColor: ColorPalette.buttonColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                shadowColor: Colors.black.withOpacity(0.25),
                elevation: 8,
              ),
              child: const Text(
                "Gửi Phản Hồi",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
