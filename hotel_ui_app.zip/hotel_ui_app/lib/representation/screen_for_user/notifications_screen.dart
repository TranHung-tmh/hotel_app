import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hotel_ui_app/representation/screen_for_user/call_service_screen.dart';
import 'package:hotel_ui_app/representation/screens/add_using_service_screen.dart';
import 'package:hotel_ui_app/representation/widgets/app_bar_container.dart';
import 'package:hotel_ui_app/representation/widgets/item_using_service_widget.dart';
import '../../core/constant/color_constant.dart';
import '../../core/constant/dismension_constant.dart';
import '../../core/helper/shared_preferences_helper.dart';
import '../../core/service/api_service.dart';
import '../widgets/item_services_widget.dart';  // Import widget mới

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({Key? key}) : super(key: key);

  static const routeName = '/notifications_screen';

  @override
  State<NotificationsScreen> createState() => _UsingServicesScreenState();
}

class _UsingServicesScreenState extends State<NotificationsScreen> {
  String _customerId = "";
  final ApiService apiService = ApiService();
  List<dynamic> using = [];
  bool isLoading = true;


  @override
  void initState() {
    super.initState();
    _loadCustomerInfo();
    fetchUserServices();
  }


  Future<void> fetchUserServices() async {
    if (_customerId.isEmpty) return;
    try {
      final data = await apiService.getSuDungDVByCustomer(_customerId);
      setState(() {
        if (data.isEmpty) {
          using = [];
        } else {
          using = data;
        }
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Lỗi khi tải dữ liệu')),
      );
    }
  }


  Future<void> _loadCustomerInfo() async {
    try {
      final customerId = await SharedPreferencesHelper.getCustomerId();
      if (customerId != null) {
        setState(() {
          _customerId = customerId;
        });
        fetchUserServices();
      } else {
        throw Exception("Customer ID không tồn tại");
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi: $e')),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
        child: Column(
          children: [
            Expanded(child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : using.isEmpty
                ? const Center(child: Text('Không có lượt nào để hiển thị'))
                : ListView.builder(
              itemCount: using.length,
              itemBuilder: (context, index) {
                final usings = using[index];
                final customerId = usings['MaKhachHang'];
                final serviceName = usings['DichVu']?['TenDichVu'] ?? 'Không rõ tên dịch vụ';
                final customerName = usings['KhachHang']?['Ten'] ?? 'Không rõ tên khách hàng';
                final quantity = usings['SoLuong'] ?? 'Không có số lượng';
                final totalAmount = usings['TongTien'] ?? 'Không rõ';
                final note = usings['ghiChu'] ?? 'Khong Co';
                final status = usings['TrangThai'] ?? 'Khong ro';

                  return ItemServicesWidget(
                    icon: FontAwesomeIcons.bellConcierge,
                    label: serviceName,
                    value: 'Khách Hàng: $customerName',
                    detail: {
                      'Tổng Tiền': '$totalAmount VND',
                      'Số Lượng': '$quantity lần',
                      'Ghi Chu': '$note' ,
                      'Trang Thai': '$status',
                    },
                  );
              },
            ),
            ),
            SizedBox(
              height: kMediumPadding,
            ),
            SizedBox(
              width: double.infinity, // Đặt chiều rộng nút chiếm toàn bộ chiều ngang
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pushNamed(CallServiceScreen.routeName);
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: ColorPalette.buttonColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  shadowColor: Colors.black.withOpacity(0.25),
                  elevation: 8,
                ),
                child: const Text(
                  "Gọi Dịch Vụ Mới",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            )
          ],
        )
    );
  }
}
