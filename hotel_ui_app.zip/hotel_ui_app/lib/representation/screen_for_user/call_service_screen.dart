import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hotel_ui_app/representation/screen_for_user/room_screen_user.dart';
import 'package:hotel_ui_app/representation/screen_for_user/service_screen_user.dart';
import 'package:hotel_ui_app/representation/screens/profile_screen.dart';
import 'package:hotel_ui_app/representation/screens/services_screen.dart';
import '../../core/constant/color_constant.dart';
import '../../core/constant/dismension_constant.dart';
import '../../core/helper/shared_preferences_helper.dart';
import '../../core/service/api_service.dart';
import '../screens/rooms_screen.dart';
import '../widgets/app_bar_container.dart';
import '../widgets/item_booking_widget.dart';

class CallServiceScreen extends StatefulWidget {
  const CallServiceScreen({Key? key}) : super(key: key);

  static const routeName = '/call_service_screen';

  @override
  State<CallServiceScreen> createState() => _AddUsingServiceScreenState();
}

class _AddUsingServiceScreenState extends State<CallServiceScreen> {
  final ApiService apiService = ApiService();
  final _noteController = TextEditingController();
  String? selectedCustomerId;
  String? selectedCustomerName;
  String? selectedServiceId;
  String? selectedServiceName;
  String? selectedRoomId;
  String? note;
  String status = "Chua Duoc Duyet";
  String selectedRoomName = "Chưa chọn phòng";
  DateTime usingDate = DateTime.now();
  int quantity = 1;

  Future<void> _createUsingService() async {
    note = _noteController.text;
    if (selectedCustomerId == null ||
        selectedServiceId == null ||
        usingDate == null||
        quantity == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Vui lòng nhập đầy đủ thông tin!")),
      );
      return;
    }

    final formData = {
      "MaKhachHang": int.tryParse(selectedCustomerId!),
      "MaDichVu": int.tryParse(selectedServiceId!),
      "NgaySuDung": usingDate!.toIso8601String().split("T").first,
      "SoLuong": quantity,
      "GhiChu": note,
      "TrangThai":status
    };

    try {
      bool success = await apiService.createServiceUsage(formData);
      print(formData);
      if (success) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Đặt dịch vụ thành công! ")),
        );
        Navigator.of(context).pop();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Đặt dịch vụ thất bại!")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Lỗi: $e")),
      );
    }
  }

  Future<void> _loadCustomerData() async {
    final customerId = await SharedPreferencesHelper.getCustomerId();
    final customerName = await SharedPreferencesHelper.getCustomerName();
    setState(() {
      selectedCustomerId = customerId;
      selectedCustomerName = customerName ?? "Chưa có tên";
    });
  }

  @override
  void initState() {
    super.initState();
    _loadCustomerData();
  }



  @override
  Widget build(BuildContext context) {
    return AppBarContainer(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            ItemBookingWidget(
              icon: FontAwesomeIcons.solidUser,
              label: "Thông tin khách hàng: ",
              value: selectedCustomerName != null
                  ? '$selectedCustomerName': "Chưa tải",
            ),
            ItemBookingWidget(
              icon: Icons.room_service,
              label: "Dịch vụ:",
              value: selectedServiceName != null
                  ? '$selectedServiceName'
                  : 'Chọn dịch vụ',
              onTap: () async {
                final result = await Navigator.of(context).pushNamed(ServiceScreenUser.routeName);
                if (result != null && result is Map) {
                  setState(() {
                    selectedServiceId = result['id'] ?? '';
                    selectedServiceName = result['name'] ?? '';
                  });
                }
              },
            ),
            ItemBookingWidget(
              icon: Icons.bed,
              label: "Thông Tin Phòng:",
              value: selectedRoomName != null
                  ? '$selectedRoomName'
                  : 'Chon Phong',
              onTap: () async {
                final result = await Navigator.of(context).pushNamed(RoomScreenUser.routeName);
                if (result != null && result is Map) {
                  setState(() {
                    selectedRoomId = result['id'] ?? '';
                    selectedRoomName = result['name'] ?? '';
                  });
                }
              },
            ),
            const Text(
              "Ghi chú:",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            TextFormField(
              controller: _noteController,
              maxLines: 4,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Nhập nội dung ghi chú tại đây...',
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Vui lòng nhập nội dung ghi chú!';
                }
                return null;
              },
            ),
            const SizedBox(height: kDefaultPadding),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _createUsingService,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: ColorPalette.buttonColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  shadowColor: Colors.black.withOpacity(0.25),
                  elevation: 8,
                ),
                child: const Text(
                  "Gọi Dịch Vụ",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

}
