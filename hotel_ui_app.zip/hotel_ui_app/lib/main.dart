import 'package:flutter/material.dart';
import 'package:hotel_ui_app/core/constant/color_constant.dart';
import 'package:hotel_ui_app/representation/screens/splash_screen.dart';
import 'package:hotel_ui_app/routes.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Hotel Booking App',
      theme: ThemeData(
        primaryColor: ColorPalette.primaryColor,
        scaffoldBackgroundColor: ColorPalette.backgroundScaffoldColor,
        dialogBackgroundColor: ColorPalette.backgroundScaffoldColor
      ),
      routes: routes,
      debugShowCheckedModeBanner: false,
      home: const SplashScreen(),
    );
  }
}


