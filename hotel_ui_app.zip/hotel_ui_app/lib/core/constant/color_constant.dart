import 'package:flutter/material.dart';

class ColorPalette {
  static const Color primaryColor = Color(0xFF598BD5);
  static const Color yellowColor = Color(0xffFFB11B);
  static const Color thirdColor = Color(0xFF94BCE1);
  static const Color secondColor = Color(0xFF85A9E6);

  static const Color dividerColor = Color(0xffE5E7EB);
  static const Color text1Color = Color(0xff323B4B);
  static const Color subTitleColor = Color(0xff838383);
  static const Color backgroundColor = Color(0xffF7F7F7);
  static const Color backgroundScaffoldColor = Color(0xffF2F2F2);
  
  static const Color buttonColor = Color(0xFF598BD5);
}

class Gradients {
  static const Gradient defaultGradientBackground = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
      ColorPalette.primaryColor,
      ColorPalette.secondColor,
      ColorPalette.thirdColor,
    ],
    stops: [0.0, 0.5, 1.0], // Phân bổ màu theo tỷ lệ
  );
}


