import 'package:shared_preferences/shared_preferences.dart';

class SharedPreferencesHelper {
  // Lưu customerId vào SharedPreferences
  static Future<void> saveCustomerId(String customerId) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('customerId', customerId); // Lưu customerId
  }

  // Lấy customerId từ SharedPreferences
  static Future<String?> getCustomerId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('customerId'); // Lấy customerId
  }

  static Future<void> saveUserRole(String role) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('role', role); // Lưu customerId
  }

  static Future<String?> getUserRole() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('role');
  }

  static Future<void> saveCustomerName(String customerName) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('customerName', customerName);
  }

  static Future<String?> getCustomerName() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('customerName');
  }

  static Future<void> saveUsingId(String usingId) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('MaSuDungDv', usingId);
  }

  static Future<String?> getUsingId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('MaSuDungDv');
  }

}
