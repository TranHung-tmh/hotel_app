class AssetHelper{
  static const String imageBackgroundintro = 'assets/images/background_intro.png';
  static const String imageNameintro = 'assets/images/name_intro.png';
  static const String imageIntro1 = 'assets/images/intro_1.png';
  static const String imageIntro2 = 'assets/images/intro_2.png';
  static const String imageIntro3 = 'assets/images/intro_3.png';
  static const String imageLogo = 'assets/images/logo.png';
  static const String imageIntroStarted = 'assets/images/intro_started.png';
  static const String imageRoomsButton = 'assets/images/rooms_btn.png';
  static const String imageFoodsButton = 'assets/images/foods_btn.png';
  static const String imageServiceButton = 'assets/images/services_btn.png';
  static const String imageHaLong = 'assets/images/imgHaLong.png';
  static const String imageVungTau = 'assets/images/imgVungTau.png';
  static const String imagePhuQuoc = 'assets/images/imgPhuQuoc.png';
  static const String imageNhaTrang = 'assets/images/NhaTrang.png';
  static const String iconLocation = 'assets/images/icon_location.png';
  static const String iconRoom = 'assets/images/icon_room.png';
  static const String iconCalendar= 'assets/images/icon_calendar.png';
  static const String imageMaintenanceButton = 'assets/images/maintenance_btn.png';
  static const String imageProfile = 'assets/images/img_profile.png';
}