import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class ApiService {
  // final String baseUrlPhong = 'http://172.21.11.78:3000/api/v1/phong';
  // final String baseUrlDichVu = 'http://172.21.11.78:8080/api/v1/dichvu';
  // final String baseUrlPhanHoi = 'http://172.21.11.78:6000/api/v1/phanhoi';
  // final String baseUrlKhachHang = 'http://172.21.11.78:7000/api/v1/khachhang';
  // final String baseUrlSuDungDV = 'http://172.21.11.78:9000/api/v1/sudungdv';
  // final String baseUrlYCBaotri = 'http://172.21.11.78:10000/api/v1/yeucaubaotri';
  // final String baseUrlDatPhong = 'http://172.21.11.78:20000/api/v1/datphong';
  // final String baseUrlTK = 'http://172.21.11.78:8000/api/v1/users';

  final String baseUrlPhong = 'http://192.168.1.14:3000/api/v1/phong';
  final String baseUrlDichVu = 'http://192.168.1.14:8080/api/v1/dichvu';
  final String baseUrlPhanHoi = 'http://192.168.1.14:6000/api/v1/phanhoi';
  final String baseUrlKhachHang = 'http://192.168.1.14:7000/api/v1/khachhang';
  final String baseUrlSuDungDV = 'http://192.168.1.14:9000/api/v1/sudungdv';
  final String baseUrlYCBaotri = 'http://192.168.1.14:10000/api/v1/yeucaubaotri';
  final String baseUrlDatPhong = 'http://192.168.1.14:20000/api/v1/datphong';
  final String baseUrlTK = 'http://192.168.1.14:8000/api/v1/users';


  Future<List<dynamic>> fetchAllRooms() async {
    final url = Uri.parse('$baseUrlPhong/getallPhong');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      return jsonData['data'];
    } else {
      throw Exception('Failed to load rooms: ${response.statusCode}');
    }
  }

  Future<bool> deleteRooms(int roomId) async {
    final url = Uri.parse('$baseUrlPhong/deletePhong/$roomId');
    final response = await http.delete(url);

    if (response.statusCode == 200) {
      return true;
    } else {
      throw Exception('Failed to delete room: ${response.statusCode}');
    }
  }

  Future<bool> createRoom(String roomNumber, String roomType, String roomPrice,
      String roomStatus) async {
    final url = Uri.parse('$baseUrlPhong/createPhong');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'SoPhong': roomNumber,
        'LoaiPhong': roomType,
        'GiaPhong': roomPrice,
        'TinhTrang': roomStatus,
      }),
    );
    if (response.statusCode == 200) {
      return true;
    } else {
      throw Exception('Failed to create room: ${response.statusCode}');
    }
  }



  Future<List<dynamic>> fetchAllServices() async {
    final url = Uri.parse('$baseUrlDichVu/getallDV');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      return jsonData['data'];
    } else {
      throw Exception('Failed to load Services: ${response.statusCode}');
    }
  }

  Future<bool> createService(String serviceName, String description,
      String price) async {
    final response = await http.post(
      Uri.parse('$baseUrlDichVu/createDV'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'TenDichVu': serviceName,
        'MoTa': description,
        'GiaDichVu': price,
      }),
    );

    return response.statusCode == 201; // Thành công nếu trả về 201
  }


  Future<List<dynamic>> fetchAllFeedBack() async {
    final url = Uri.parse('$baseUrlPhanHoi/getallPhanHoi');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      return jsonData['data'];
    } else {
      throw Exception('Failed to load Services: ${response.statusCode}');
    }
  }

  Future<bool> createFeedback(
      String customerId,
      String serviceId,
      String comment,
      DateTime daySend,
      String type,
      ) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrlPhanHoi/createPhanHoi'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'MaKhachHang': customerId,
          'MaDichVu': serviceId,
          'NoiDung': comment,
          'NgayGui': daySend.toIso8601String(),
          'LoaiPh': type,
        }),
      );
      if (kDebugMode) {
        print('Response status: ${response.statusCode}');
        print('Response body: ${response.body}');
      }

      // Kiểm tra mã trạng thái phản hồi
      if (response.statusCode == 201) {
        return true;
      } else {
        // In lỗi khi mã trạng thái khác thành công
        print('Failed to create feedback: ${response.statusCode} - ${response.body}');
        return false;
      }
    } catch (e) {
      // Bắt lỗi ngoại lệ
      print('Exception occurred: $e');
      return false;
    }
  }


  Future<bool> deleteFeedBack(int fbId) async {
    final url = Uri.parse('$baseUrlPhanHoi/deletePhanHoi/$fbId');
    final response = await http.delete(url);

    if (response.statusCode == 200) {
      return true;
    } else {
      throw Exception('Failed to delete service: ${response.statusCode}');
    }
  }

  Future<List<dynamic>> fetchAllCustomers() async {
    final url = Uri.parse('$baseUrlKhachHang/getallKH');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      return jsonData['data'];
    } else {
      throw Exception('Failed to load Services: ${response.statusCode}');
    }
  }

  Future<Map<String, dynamic>> fetchCustomerById(String customerId) async {
    final url = Uri.parse('$baseUrlKhachHang/getKH/$customerId');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      return jsonData['data'];
    } else {
      throw Exception('Failed to load customer data: ${response.statusCode}');
    }
  }

  Future<bool> createCustomer(String customerId,
      String name,
      String phone,
      String email,
      String address,
      String dob,
      String type,
      String img,) async {
    final url = Uri.parse('$baseUrlKhachHang/createKH');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'MaKhachHang': customerId,
        "Ten": name,
        "SDT": phone,
        "Email": email,
        "DiaChi": address,
        "NgaySinh": dob,
        "Loai": type,
        "HinhAnh": img,
      }),
    );

    if (response.statusCode == 201) {
      return true;
    } else {
      throw Exception('Failed to create customer: ${response.body}');
    }
  }

  Future<bool> deleteCustomer(int customerId) async {
    final url = Uri.parse('$baseUrlKhachHang/deleteKH/$customerId');
    final response = await http.delete(url);

    if (response.statusCode == 200) {
      return true;
    } else {
      throw Exception('Failed to delete service: ${response.statusCode}');
    }
  }


  Future<List<dynamic>> fetchAllUsingServices() async {
    final url = Uri.parse('$baseUrlSuDungDV/getallSDDV');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      return jsonData['data'];
    } else {
      throw Exception('Failed to load Services: ${response.statusCode}');
    }
  }

  Future<List<dynamic>> getSuDungDVByCustomer(String maKhachHang) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrlSuDungDV/getSDDVByCustomer/$maKhachHang'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['data'] ?? [];
      } else {
        return [];
      }
    } catch (e) {
      return [];
    }
  }



  Future<bool> createServiceUsage(Map<String, dynamic> formData) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrlSuDungDV/createSDDV'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'MaKhachHang': formData['MaKhachHang'],
          'MaDichVu': formData['MaDichVu'],
          'NgaySuDung': formData['NgaySuDung'],
          'SoLuong': formData['SoLuong'],
          'ghiChu': formData['GhiChu'],
          'TrangThai': formData['TrangThai'],
        }),
      );

      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 201) {
        return true;
      } else {
        print('Failed to create service usage: ${response.body}');
        return false;
      }
    } catch (e) {
      print('Exception occurred: $e');
      return false;
    }
  }

  Future<bool> acceptService(int usingId) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrlSuDungDV/duyet/$usingId'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'TrangThai': 'Đã duyệt'}),
      );

      if (response.statusCode == 200) {
        return true;
      } else {
        print('Failed to accept service: ${response.body}');
        return false;
      }
    } catch (e) {
      print('Error accepting service: $e');
      return false;
    }
  }


  Future<bool> deleteServiceUsage(int usingId) async {
    try {
      print("Gửi yêu cầu xóa tới API với ID: $usingId"); // Log kiểm tra
      final response = await http.delete(Uri.parse('$baseUrlSuDungDV/deleteSDDV/$usingId'));

      print("Status Code: ${response.statusCode}");
      print("Response Body: ${response.body}");

      if (response.statusCode == 200) {
        return true;
      } else {
        print("API trả về lỗi: ${response.statusCode} - ${response.body}");
        return false;
      }
    } catch (e) {
      print("Lỗi gọi API: $e"); // Log lỗi
      return false;
    }
  }

  Future<bool> updateTrangThai(int usingId, String status) async {
    final url = Uri.parse('$baseUrlSuDungDV/updateTrangThai/$usingId');
    final body = jsonEncode({'MaSuDungDv': usingId, 'TrangThai': status});

    print('Sending PUT request to: $url');
    print('Request body: $body');

    final response = await http.put(
      url,
      headers: {'Content-Type': 'application/json'},
      body: body,
    );

    print('Response Status Code: ${response.statusCode}');
    print('Response Body: ${response.body}');

    if (response.statusCode == 200) {
      print('Update success!');
      return true;
    } else {
      print('Update failed with status: ${response.statusCode}');
      throw Exception('Failed to update status: ${response.body}');
    }
  }



  Future<bool> deleteService(int serviceId) async {
    final url = Uri.parse('$baseUrlDichVu/deleteDV/$serviceId');
    final response = await http.delete(url);

    if (response.statusCode == 200) {
      return true;
    } else {
      throw Exception('Failed to delete service: ${response.statusCode}');
    }
  }

  Future<List<dynamic>> fetchAllMaintenanceRequest() async {
    final url = Uri.parse('$baseUrlYCBaotri/getallBaoTri');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      return jsonData['data'];
    } else {
      throw Exception('Failed to load Services: ${response.statusCode}');
    }
  }

  Future<bool> createMaintenanceRequest(String roomId,
      DateTime daySend, DateTime dayCompleted) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrlYCBaotri/createBaoTri'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'MaPhong': roomId,
          'NgayYC': "${daySend.year}-${daySend.month.toString().padLeft(2, '0')}-${daySend.day.toString().padLeft(2, '0')}",
          'NgayHoanThanh': "${dayCompleted.year}-${dayCompleted.month.toString().padLeft(2, '0')}-${dayCompleted.day.toString().padLeft(2, '0')}",
        }),
      );

      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 201) {
        return true;
      } else {
        print('Failed to create booking: ${response.body}');
        return false;
      }
    } catch (e) {
      print('Exception occurred: $e');
      return false;
    }
  }
  Future<bool> deleteMaintainance(int requestId) async {
    final url = Uri.parse('$baseUrlYCBaotri/deleteBaoTri/$requestId');
    final response = await http.delete(url);

    if (response.statusCode == 200) {
      return true;
    } else {
      throw Exception('Failed to delete service: ${response.statusCode}');
    }
  }

  Future<List<dynamic>> fetchAllBooking() async {
    final url = Uri.parse('$baseUrlDatPhong/getallDatPhong');
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      return jsonData['data'];
    } else {
      throw Exception('Failed to load Bookings: ${response.statusCode}');
    }
  }


  Future<bool> createBookingRoom(String customerId, String roomId,
      DateTime dayStart, DateTime dayBook, DateTime dayEnd) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrlDatPhong/createDatPhong'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'MaKhachHang': customerId,
          'MaPhong': roomId,
          'NgayDat': "${dayBook.year}-${dayBook.month.toString().padLeft(2, '0')}-${dayBook.day.toString().padLeft(2, '0')}",
          'NgayNhan': "${dayStart.year}-${dayStart.month.toString().padLeft(2, '0')}-${dayStart.day.toString().padLeft(2, '0')}",
          'NgayTra': "${dayEnd.year}-${dayEnd.month.toString().padLeft(2, '0')}-${dayEnd.day.toString().padLeft(2, '0')}",
        }),
      );

      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 201) {
        return true;
      } else {
        print('Failed to create booking: ${response.body}');
        return false;
      }
    } catch (e) {
      print('Exception occurred: $e');
      return false;
    }
  }

  Future<bool> deleteBooking(int bookingId) async {
    final url = Uri.parse('$baseUrlDatPhong/deleteDatPhong/$bookingId');
    final response = await http.delete(url);

    if (response.statusCode == 200) {
      return true;
    } else {
      throw Exception('Failed to delete service: ${response.statusCode}');
    }
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrlTK/login'), // Kiểm tra baseUrlTK có đúng không
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'email': email, 'password': password}),
      );

      if (response.statusCode == 200) {
        // Nếu login thành công, trả về dữ liệu
        final data = json.decode(response.body);
        if (data != null && data.containsKey('data')) {
          return data; // Trả về toàn bộ dữ liệu nếu thành công
        } else {
          throw Exception('Dữ liệu không hợp lệ');
        }
      } else {
        // Nếu có lỗi, trả về lỗi
        final errorData = json.decode(response.body);
        throw Exception(errorData['message'] ?? 'Lỗi không xác định');
      }
    } catch (error) {
      // Xử lý lỗi kết nối
      throw Exception('Lỗi kết nối: $error');
    }
  }

}



