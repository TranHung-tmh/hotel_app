import 'package:flutter/material.dart';
import 'package:hotel_ui_app/representation/screen_for_user/add_feedback_screen.dart';
import 'package:hotel_ui_app/representation/screen_for_user/booking_screen_user.dart';
import 'package:hotel_ui_app/representation/screen_for_user/call_service_screen.dart';
import 'package:hotel_ui_app/representation/screen_for_user/feedback_screen_user.dart';
import 'package:hotel_ui_app/representation/screen_for_user/home_screen_user.dart';
import 'package:hotel_ui_app/representation/screen_for_user/main_screen_user.dart';
import 'package:hotel_ui_app/representation/screen_for_user/notifications_screen.dart';
import 'package:hotel_ui_app/representation/screen_for_user/profile_screen_user.dart';
import 'package:hotel_ui_app/representation/screen_for_user/room_screen_user.dart';
import 'package:hotel_ui_app/representation/screen_for_user/service_screen_user.dart';
import 'package:hotel_ui_app/representation/screens/add_customer_screen.dart';
import 'package:hotel_ui_app/representation/screens/add_maintainance_screen.dart';
import 'package:hotel_ui_app/representation/screens/add_room_screen.dart';
import 'package:hotel_ui_app/representation/screens/add_services_screen.dart';
import 'package:hotel_ui_app/representation/screens/add_using_service_screen.dart';
import 'package:hotel_ui_app/representation/screens/booking_screen.dart';
import 'package:hotel_ui_app/representation/screens/feedback_screen.dart';
import 'package:hotel_ui_app/representation/screens/list_booking_screen.dart';
import 'package:hotel_ui_app/representation/screens/maintenance_request_screen.dart';
import 'package:hotel_ui_app/representation/screens/home_screen.dart';
import 'package:hotel_ui_app/representation/screens/intro_screen.dart';
import 'package:hotel_ui_app/representation/screens/login_screen.dart';
import 'package:hotel_ui_app/representation/screens/main_screen.dart';
import 'package:hotel_ui_app/representation/screens/profile_screen.dart';
import 'package:hotel_ui_app/representation/screens/register_screen.dart';
import 'package:hotel_ui_app/representation/screens/rooms_screen.dart';
import 'package:hotel_ui_app/representation/screens/select_date_screen.dart';
import 'package:hotel_ui_app/representation/screens/services_screen.dart';
import 'package:hotel_ui_app/representation/screens/splash_screen.dart';
import 'package:hotel_ui_app/representation/screens/stundent_info_screen.dart';
import 'package:hotel_ui_app/representation/screens/using_service_screen.dart';


final Map<String, WidgetBuilder> routes = {
  SplashScreen.routeName: (context) => const SplashScreen(),
  IntroScreen.routeName: (context) => const IntroScreen(),
  LoginScreen.routeName: (context) => const LoginScreen(),
  RegisterScreen.routeName: (context) => const RegisterScreen(),
  MainScreen.routeName: (context) => const MainScreen(),
  HomeScreen.routeName: (context) => const HomeScreen(),
  BookingScreen.routeName: (context) => const BookingScreen(),
  FeedbackScreen.routeName: (context) => const FeedbackScreen(),
  ProfileScreen.routeName: (context) => const ProfileScreen(),
  RoomsScreen.routeName: (context) => const RoomsScreen(),
  MaintenanceRequestScreen.routeName: (context) => const MaintenanceRequestScreen(),
  ServicesScreen.routeName : (context) => const ServicesScreen(),
  SelectDateScreen.routeName: (context) => SelectDateScreen(),
  UsingServicesScreen.routeName: (context) => const UsingServicesScreen(),
  AddRoomScreen.routeName : (context) => const AddRoomScreen(),
  AddServiceScreen.routeName : (context) => const AddServiceScreen(),
  AddCustomerScreen.routeName : (context) => const AddCustomerScreen(),
  StundentInfoScreen.routeName: (context) => const StundentInfoScreen(),
  ListBookingScreen.routeName: (context) => const ListBookingScreen(),
  AddMaintainanceScreen.routeName: (context) => const AddMaintainanceScreen(),
  AddUsingServiceScreen.routeName: (context) => const AddUsingServiceScreen(),
  HomeScreenUser.routeName: (context) => const HomeScreenUser(),
  BookingScreenUser.routeName: (context) => const BookingScreenUser(),
  FeedbackScreenUser.routeName: (context) => const FeedbackScreenUser(),
  MainScreenUser.routeName: (context) => const MainScreenUser(),
  ProfileScreenUser.routeName: (context) => const ProfileScreenUser(),
  RoomScreenUser.routeName: (context) => const RoomScreenUser(),
  ServiceScreenUser.routeName: (context) => const ServiceScreenUser(),
  CallServiceScreen.routeName: (context) => const CallServiceScreen(),
  AddFeedbackScreen.routeName: (context) => const AddFeedbackScreen(),
  NotificationsScreen.routeName: (context) => const NotificationsScreen(),
};