package com.example.hotel_ui_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
